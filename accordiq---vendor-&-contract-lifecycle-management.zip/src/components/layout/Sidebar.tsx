import React from 'react';
import { useCLM } from '../../context/CLMContext';
import { ActiveTab } from '../../types/clm';
import { 
  FileText, 
  Clock, 
  CheckSquare, 
  FileSignature, 
  Users, 
  Building2, 
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  FolderGit2
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, contracts, obligations } = useCLM();

  const urgentRenewalsCount = contracts.filter(c => c.status === 'renewal_due').length;
  const atRiskObligationsCount = obligations.filter(o => o.status === 'at_risk' || o.status === 'overdue').length;
  const pendingDocuSignCount = contracts.filter(c => c.status === 'out_for_signature').length;
  const inReviewCount = contracts.filter(c => c.status === 'legal_review' || c.status === 'procurement_review').length;

  const navigation: { id: ActiveTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number; badgeColor?: string }[] = [
    {
      id: 'contracts',
      label: 'Contract Repository',
      icon: FileText,
      badge: contracts.length
    },
    {
      id: 'renewals',
      label: 'Renewal Radar & Alerts',
      icon: Clock,
      badge: urgentRenewalsCount > 0 ? urgentRenewalsCount : undefined,
      badgeColor: 'bg-rose-500 text-white animate-pulse'
    },
    {
      id: 'obligations',
      label: 'Obligations & SLAs',
      icon: CheckSquare,
      badge: atRiskObligationsCount > 0 ? atRiskObligationsCount : undefined,
      badgeColor: 'bg-amber-500 text-white'
    },
    {
      id: 'docusign',
      label: 'DocuSign E-Signature',
      icon: FileSignature,
      badge: pendingDocuSignCount > 0 ? pendingDocuSignCount : undefined,
      badgeColor: 'bg-blue-600 text-white'
    },
    {
      id: 'collaboration',
      label: 'Legal & Procurement Hub',
      icon: Users,
      badge: inReviewCount > 0 ? inReviewCount : undefined,
      badgeColor: 'bg-purple-100 text-purple-700'
    },
    {
      id: 'vendors',
      label: 'Vendor Management',
      icon: Building2
    },
    {
      id: 'audit',
      label: 'Audit Trail & Compliance',
      icon: ShieldCheck
    }
  ];

  // Quick total metrics
  const totalValueSum = contracts.reduce((acc, c) => acc + c.totalValue, 0);

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex-shrink-0 flex flex-col justify-between border-r border-slate-800 hidden md:flex min-h-[calc(100vh-4rem)]">
      <div className="p-4 space-y-6">
        {/* Navigation list */}
        <div className="space-y-1">
          <p className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">Platform Modules</p>
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                  isActive 
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/20 font-semibold' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`h-4 w-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Portfolio Quick Snapshot */}
        <div className="bg-slate-800/80 rounded-xl p-3.5 border border-slate-700/60 text-xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="font-semibold uppercase tracking-wider text-[10px]">Active Portfolio</span>
            <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-white tracking-tight">
            ${(totalValueSum / 1000).toFixed(0)}k <span className="text-[11px] font-normal text-slate-400">Total Run-rate</span>
          </div>
          <div className="mt-2.5 pt-2 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-300">
            <span>Critical Tier 1:</span>
            <span className="font-semibold text-purple-300">
              {contracts.filter(c => c.tier.includes('Tier 1')).length} vendors
            </span>
          </div>
          <div className="mt-1 flex items-center justify-between text-[11px] text-slate-300">
            <span>DocuSign Envelopes:</span>
            <span className="font-semibold text-sky-300">
              {contracts.filter(c => c.envelope).length} tracked
            </span>
          </div>
        </div>
      </div>

      {/* Compliance & Audit Footer Status */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
          <span className="font-medium text-slate-300">Audit Sentinel Active</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">SOX / SOC 2 Type II tamper-evident ledger tracking all edits.</p>
      </div>
    </aside>
  );
};
