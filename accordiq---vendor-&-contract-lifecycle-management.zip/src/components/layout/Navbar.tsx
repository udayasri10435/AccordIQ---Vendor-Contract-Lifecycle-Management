import React, { useState } from 'react';
import { useCLM, AVAILABLE_USERS } from '../../context/CLMContext';
import { 
  FileSignature, 
  Plus, 
  RotateCcw, 
  Bell, 
  ChevronDown, 
  Sparkles,
  Search,
  Scale,
  Briefcase
} from 'lucide-react';

interface NavbarProps {
  onOpenNewContractModal: () => void;
  onSearchChange: (query: string) => void;
  searchQuery: string;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onOpenNewContractModal, 
  onSearchChange, 
  searchQuery 
}) => {
  const { 
    currentUser, 
    setCurrentUser, 
    contracts, 
    obligations, 
    setActiveTab, 
    setSelectedContractId,
    resetAllData 
  } = useCLM();

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  // Critical renewals: expiry in next 45 days or status === 'renewal_due'
  const urgentRenewals = contracts.filter(c => c.status === 'renewal_due');
  const atRiskObligations = obligations.filter(o => o.status === 'at_risk' || o.status === 'overdue');

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
      {/* Critical Renewal Warning Ribbon if urgent renewals exist */}
      {urgentRenewals.length > 0 && (
        <div className="bg-gradient-to-r from-amber-600 via-rose-600 to-amber-700 text-white px-4 py-1.5 text-xs sm:text-sm font-medium flex items-center justify-between">
          <div className="flex items-center gap-2 max-w-5xl mx-auto w-full">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
            </span>
            <span>
              <strong>URGENT RENEWAL NOTICE:</strong> {urgentRenewals.length} contract{urgentRenewals.length > 1 ? 's require' : ' requires'} immediate notice decision to prevent non-negotiated price escalation (e.g. <em>{urgentRenewals[0].title}</em>).
            </span>
            <button 
              onClick={() => {
                setActiveTab('renewals');
                setSelectedContractId(urgentRenewals[0].id);
              }}
              className="ml-auto underline font-bold hover:text-amber-100 whitespace-nowrap cursor-pointer text-xs"
            >
              Action Renewal Radar &rarr;
            </button>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-slate-900 flex items-center justify-center text-white shadow-md shadow-slate-900/10">
              <Scale className="h-5 w-5 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-slate-900">Accord<span className="text-indigo-600">IQ</span></span>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide uppercase bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Enterprise CLM
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium hidden sm:block">Legal &amp; Procurement Lifecycle Hub</p>
            </div>
          </div>

          {/* Central Search */}
          <div className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input 
                type="text"
                placeholder="Search contracts, vendors, clauses, or DocuSign envelopes..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-colors"
              />
              {searchQuery && (
                <button 
                  onClick={() => onSearchChange('')} 
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Right Actions & Persona */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Create Contract Button */}
            <button 
              onClick={onOpenNewContractModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold shadow-xs hover:shadow transition-all cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">New Contract</span>
            </button>

            {/* Notification Bell */}
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                title="Alerts & Obligations"
              >
                <Bell className="h-5 w-5" />
                {(urgentRenewals.length + atRiskObligations.length > 0) && (
                  <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-rose-500 ring-2 ring-white animate-pulse" />
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 z-50 p-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3">
                    <h4 className="font-semibold text-sm text-slate-900">Urgent Alerts ({urgentRenewals.length + atRiskObligations.length})</h4>
                    <span className="text-xs text-slate-500">Auto-synced</span>
                  </div>

                  <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                    {urgentRenewals.map(c => (
                      <div 
                        key={c.id} 
                        onClick={() => {
                          setSelectedContractId(c.id);
                          setActiveTab('renewals');
                          setShowNotifications(false);
                        }}
                        className="p-2.5 bg-rose-50/70 border border-rose-200 rounded-lg hover:bg-rose-100 cursor-pointer transition-colors text-left"
                      >
                        <div className="flex items-center justify-between text-xs font-semibold text-rose-800">
                          <span>Renewal Window Notice</span>
                          <span>Due: {c.endDate}</span>
                        </div>
                        <p className="text-xs text-slate-800 font-medium mt-1 truncate">{c.title}</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Notice required: {c.noticePeriodDays} days before renewal.</p>
                      </div>
                    ))}

                    {atRiskObligations.map(o => (
                      <div 
                        key={o.id}
                        onClick={() => {
                          setActiveTab('obligations');
                          setShowNotifications(false);
                        }}
                        className="p-2.5 bg-amber-50/70 border border-amber-200 rounded-lg hover:bg-amber-100 cursor-pointer transition-colors text-left"
                      >
                        <div className="flex items-center justify-between text-xs font-semibold text-amber-800">
                          <span>Obligation At Risk: {o.type}</span>
                          <span>{o.dueDate}</span>
                        </div>
                        <p className="text-xs text-slate-800 font-medium mt-1 truncate">{o.title}</p>
                        <p className="text-[11px] text-slate-600 mt-0.5">Assigned to: {o.assigneeName} ({o.assignedRole})</p>
                      </div>
                    ))}

                    {urgentRenewals.length === 0 && atRiskObligations.length === 0 && (
                      <div className="text-center py-6 text-slate-500 text-xs">
                        No critical renewal or obligation alerts right now. Everything is on schedule!
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Persona Switcher Dropdown (Legal Counsel vs Procurement Lead) */}
            <div className="relative">
              <button 
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer text-left"
              >
                <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-indigo-600 to-sky-500 text-white flex items-center justify-center font-bold text-xs">
                  {currentUser.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="hidden lg:block text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-900 leading-none">{currentUser.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                      currentUser.role === 'Legal' 
                        ? 'bg-purple-100 text-purple-800' 
                        : currentUser.role === 'Procurement' 
                        ? 'bg-sky-100 text-sky-800' 
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {currentUser.role}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 leading-none block mt-0.5 truncate max-w-[140px]">{currentUser.title}</span>
                </div>
                <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
              </button>

              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 z-50 p-2">
                  <div className="px-3 py-2 border-b border-slate-100 mb-1">
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Switch Active Role (Collaboration Test)</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">Toggle between Legal Counsel &amp; Procurement Lead</p>
                  </div>
                  <div className="space-y-1">
                    {AVAILABLE_USERS.map((user) => (
                      <button 
                        key={user.email}
                        onClick={() => {
                          setCurrentUser(user);
                          setIsUserMenuOpen(false);
                        }}
                        className={`w-full flex items-center justify-between p-2 rounded-lg text-left text-xs transition-colors cursor-pointer ${
                          currentUser.email === user.email 
                            ? 'bg-indigo-50 text-indigo-900 font-semibold' 
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className={`h-6 w-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                            user.role === 'Legal' ? 'bg-purple-100 text-purple-700' : 'bg-sky-100 text-sky-700'
                          }`}>
                            {user.role[0]}
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">{user.name}</div>
                            <div className="text-[10px] text-slate-500">{user.title}</div>
                          </div>
                        </div>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                          user.role === 'Legal' ? 'bg-purple-50 text-purple-700' : 'bg-sky-50 text-sky-700'
                        }`}>
                          {user.role}
                        </span>
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 mt-2 border-t border-slate-100">
                    <button 
                      onClick={() => {
                        resetAllData();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-2 py-1.5 text-xs text-slate-500 hover:text-slate-800 hover:bg-slate-50 rounded transition-colors cursor-pointer"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                      <span>Reset Sample Data &amp; Logs</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>
    </header>
  );
};
