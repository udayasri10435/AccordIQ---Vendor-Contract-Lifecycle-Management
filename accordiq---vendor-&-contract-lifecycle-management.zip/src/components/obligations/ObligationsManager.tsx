import React, { useState } from 'react';
import { useCLM } from '../../context/CLMContext';
import { Obligation } from '../../types/clm';
import { ObligationStatusBadge } from '../common/Badge';
import { 
  CheckSquare, 
  AlertTriangle, 
  Plus, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ShieldAlert, 
  ExternalLink,
  Filter,
  X,
  Calendar,
  UserCheck
} from 'lucide-react';

export const ObligationsManager: React.FC = () => {
  const { obligations, updateObligationStatus, addObligation, contracts, setSelectedContractId } = useCLM();

  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [evidenceModal, setEvidenceModal] = useState<Obligation | null>(null);
  const [evidenceUrl, setEvidenceUrl] = useState('');
  const [completionNotes, setCompletionNotes] = useState('');

  // New obligation form state
  const [newObligation, setNewObligation] = useState({
    contractId: contracts[0]?.id || '',
    title: '',
    description: '',
    type: 'SLA' as Obligation['type'],
    dueDate: '',
    recurrence: 'one-time' as Obligation['recurrence'],
    assignedRole: 'Legal' as Obligation['assignedRole'],
    assigneeName: 'Rachel Zane',
    penaltyTerms: ''
  });

  const filteredObligations = obligations.filter(o => {
    if (filterType !== 'all' && o.type !== filterType) return false;
    if (filterStatus !== 'all' && o.status !== filterStatus) return false;
    return true;
  });

  const atRiskCount = obligations.filter(o => o.status === 'at_risk' || o.status === 'overdue').length;
  const metCount = obligations.filter(o => o.status === 'met').length;
  const pendingCount = obligations.filter(o => o.status === 'pending' || o.status === 'in_progress').length;

  const handleMarkMet = (ob: Obligation) => {
    setEvidenceModal(ob);
    setEvidenceUrl(ob.evidenceUrl || 'https://compliance.internal.corp/audit/' + ob.id + '.pdf');
    setCompletionNotes('Verified and certified deliverables compliant with contractual SLA.');
  };

  const handleConfirmEvidence = () => {
    if (!evidenceModal) return;
    updateObligationStatus(evidenceModal.id, 'met', completionNotes, evidenceUrl);
    setEvidenceModal(null);
  };

  const handleCreateObligation = (e: React.FormEvent) => {
    e.preventDefault();
    const contract = contracts.find(c => c.id === newObligation.contractId);
    if (!contract) return;

    addObligation({
      ...newObligation,
      contractTitle: contract.title,
      vendorName: contract.vendorName,
      status: 'pending'
    });

    setIsAddModalOpen(false);
    setNewObligation({
      contractId: contracts[0]?.id || '',
      title: '',
      description: '',
      type: 'SLA',
      dueDate: '',
      recurrence: 'one-time',
      assignedRole: 'Legal',
      assigneeName: 'Rachel Zane',
      penaltyTerms: ''
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Contractual Obligations &amp; SLAs</h1>
            <span className="px-2 py-0.5 rounded text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
              Deliverables Tracker
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Track vendor milestones, quarterly uptime SLAs, insurance policy renewals (COI), and SOC 2 audits to safeguard against contractual breach.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer transition-colors"
        >
          <Plus className="h-4 w-4" />
          <span>Add Obligation</span>
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">At Risk / Overdue</span>
            <span className="text-2xl font-bold text-rose-600 mt-0.5 block">{atRiskCount}</span>
            <span className="text-[11px] text-slate-500">Requires immediate attention</span>
          </div>
          <div className="h-10 w-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <ShieldAlert className="h-5 w-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">In Flight / Pending</span>
            <span className="text-2xl font-bold text-amber-600 mt-0.5 block">{pendingCount}</span>
            <span className="text-[11px] text-slate-500">Active tracking</span>
          </div>
          <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Clock className="h-5 w-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Verified &amp; Met</span>
            <span className="text-2xl font-bold text-emerald-600 mt-0.5 block">{metCount}</span>
            <span className="text-[11px] text-slate-500">Audit proof logged</span>
          </div>
          <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-500">Category:</span>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Categories</option>
              <option value="SLA">SLA Performance</option>
              <option value="Compliance & Audit">Compliance &amp; SOC2 Audit</option>
              <option value="Insurance (COI)">Insurance (COI)</option>
              <option value="Security Review">Security Review</option>
              <option value="Financial & Billing">Financial &amp; Billing</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-500">Status:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Statuses</option>
              <option value="at_risk">At Risk</option>
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="met">Met &amp; Verified</option>
              <option value="overdue">Overdue</option>
            </select>
          </div>
        </div>

        <span className="text-xs text-slate-500">
          Showing {filteredObligations.length} obligations
        </span>
      </div>

      {/* Obligations List */}
      <div className="space-y-3">
        {filteredObligations.map((ob) => (
          <div 
            key={ob.id}
            className={`bg-white border rounded-xl p-4 transition-all shadow-xs ${
              ob.status === 'at_risk' || ob.status === 'overdue' 
                ? 'border-amber-300 ring-1 ring-amber-400/20' 
                : 'border-slate-200 hover:border-slate-300'
            }`}
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              
              {/* Obligation title & context */}
              <div className="space-y-1 max-w-2xl">
                <div className="flex items-center gap-2">
                  <ObligationStatusBadge status={ob.status} />
                  <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    {ob.type}
                  </span>
                  {ob.recurrence && (
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                      &bull; {ob.recurrence}
                    </span>
                  )}
                </div>
                
                <h3 className="text-sm font-bold text-slate-900">{ob.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{ob.description}</p>
                
                <div className="flex items-center gap-2 text-[11px] text-slate-500 pt-1">
                  <span>Contract:</span>
                  <button 
                    onClick={() => setSelectedContractId(ob.contractId)} 
                    className="font-medium text-indigo-600 hover:underline cursor-pointer"
                  >
                    {ob.contractTitle}
                  </button>
                  <span>&bull;</span>
                  <span>Vendor: <strong className="text-slate-700">{ob.vendorName}</strong></span>
                </div>
              </div>

              {/* Assignment & Due Date */}
              <div className="flex flex-wrap lg:flex-col items-start lg:items-end justify-between gap-2 text-xs">
                <div>
                  <span className="text-slate-400 text-[11px] block">Due Milestone</span>
                  <span className={`font-bold ${
                    ob.status === 'at_risk' || ob.status === 'overdue' ? 'text-rose-600' : 'text-slate-900'
                  }`}>
                    {ob.dueDate}
                  </span>
                </div>

                <div className="text-left lg:text-right">
                  <span className="text-slate-400 text-[11px] block">Assigned Owner</span>
                  <span className="font-semibold text-slate-700">{ob.assigneeName}</span>
                  <span className="text-[10px] text-slate-400 block">({ob.assignedRole})</span>
                </div>

                {/* Mark Met or View Evidence action */}
                <div className="pt-1 flex items-center gap-2">
                  {ob.status === 'met' ? (
                    <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>Certified Met</span>
                      {ob.evidenceUrl && (
                        <a 
                          href={ob.evidenceUrl} 
                          target="_blank" 
                          rel="noreferrer" 
                          className="text-emerald-700 hover:text-emerald-900 ml-1"
                          title="Open Evidence File"
                        >
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={() => handleMarkMet(ob)}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>Mark Met &amp; Attach Proof</span>
                    </button>
                  )}

                  {ob.status !== 'met' && (
                    <select
                      value={ob.status}
                      onChange={(e) => updateObligationStatus(ob.id, e.target.value as Obligation['status'])}
                      className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-600 cursor-pointer"
                    >
                      <option value="pending">Pending</option>
                      <option value="in_progress">In Progress</option>
                      <option value="at_risk">At Risk</option>
                      <option value="overdue">Overdue</option>
                    </select>
                  )}
                </div>

              </div>

            </div>

            {/* Penalty term note */}
            {ob.penaltyTerms && (
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-500">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-500 flex-shrink-0" />
                <span><strong>Enforceable Consequence / Penalty:</strong> {ob.penaltyTerms}</span>
              </div>
            )}
          </div>
        ))}

        {filteredObligations.length === 0 && (
          <div className="p-8 text-center bg-white rounded-xl border border-dashed border-slate-300">
            <CheckSquare className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <h4 className="text-sm font-semibold text-slate-700">No Obligations Found</h4>
            <p className="text-xs text-slate-500 mt-1">Try resetting the category or status filters.</p>
          </div>
        )}
      </div>

      {/* Modal: Mark Met & Upload Proof */}
      {evidenceModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">Verify Obligation Completion</h3>
              <button onClick={() => setEvidenceModal(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <span className="text-xs font-bold text-slate-900 block">{evidenceModal.title}</span>
                <span className="text-xs text-slate-500">{evidenceModal.contractTitle}</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Evidence / Verification File URL</label>
                <input
                  type="text"
                  value={evidenceUrl}
                  onChange={(e) => setEvidenceUrl(e.target.value)}
                  placeholder="https://cloud.storage/compliance/report_2026.pdf"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Audit Verification Notes</label>
                <textarea
                  rows={3}
                  value={completionNotes}
                  onChange={(e) => setCompletionNotes(e.target.value)}
                  placeholder="Details on verification methodology, SLA audit results, or reviewer confirmation..."
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                onClick={() => setEvidenceModal(null)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmEvidence}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-xs"
              >
                Certify &amp; Complete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add New Obligation */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-base">Schedule Contract Obligation</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateObligation} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Associated Contract</label>
                <select
                  value={newObligation.contractId}
                  onChange={(e) => setNewObligation({ ...newObligation, contractId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  required
                >
                  {contracts.map(c => (
                    <option key={c.id} value={c.id}>{c.title} ({c.vendorName})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Obligation Title</label>
                <input
                  type="text"
                  value={newObligation.title}
                  onChange={(e) => setNewObligation({ ...newObligation, title: e.target.value })}
                  placeholder="e.g. Annual SOC 2 Type II Examination Report"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Description &amp; Requirements</label>
                <textarea
                  rows={2}
                  value={newObligation.description}
                  onChange={(e) => setNewObligation({ ...newObligation, description: e.target.value })}
                  placeholder="Specify standards, deliverable formats, and verification benchmarks..."
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={newObligation.type}
                    onChange={(e) => setNewObligation({ ...newObligation, type: e.target.value as Obligation['type'] })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="SLA">SLA Performance</option>
                    <option value="Compliance & Audit">Compliance &amp; SOC2 Audit</option>
                    <option value="Insurance (COI)">Insurance (COI)</option>
                    <option value="Security Review">Security Review</option>
                    <option value="Financial & Billing">Financial &amp; Billing</option>
                    <option value="Milestone Delivery">Milestone Delivery</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Due Date</label>
                  <input
                    type="date"
                    value={newObligation.dueDate}
                    onChange={(e) => setNewObligation({ ...newObligation, dueDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Department</label>
                  <select
                    value={newObligation.assignedRole}
                    onChange={(e) => setNewObligation({ ...newObligation, assignedRole: e.target.value as Obligation['assignedRole'] })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="Legal">Legal</option>
                    <option value="Procurement">Procurement</option>
                    <option value="InfoSec">InfoSec / Security</option>
                    <option value="Vendor Lead">Vendor Technical Lead</option>
                    <option value="Finance">Finance</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Assignee Person</label>
                  <input
                    type="text"
                    value={newObligation.assigneeName}
                    onChange={(e) => setNewObligation({ ...newObligation, assigneeName: e.target.value })}
                    placeholder="e.g. Rachel Zane"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Enforceable Penalty Clause (Optional)</label>
                <input
                  type="text"
                  value={newObligation.penaltyTerms}
                  onChange={(e) => setNewObligation({ ...newObligation, penaltyTerms: e.target.value })}
                  placeholder="e.g. 10% credit for downtime below 99.95%, or termination right after 30 days."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-xs"
                >
                  Schedule Obligation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
