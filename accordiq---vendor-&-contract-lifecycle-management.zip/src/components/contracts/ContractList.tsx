import React, { useState } from 'react';
import { useCLM } from '../../context/CLMContext';
import { Contract, ContractStatus, ContractType, ContractTier } from '../../types/clm';
import { StatusBadge, RiskBadge, TierBadge } from '../common/Badge';
import { 
  FileText, 
  Search, 
  Filter, 
  Grid, 
  List, 
  ArrowUpDown, 
  Eye, 
  FileSignature, 
  Clock, 
  Download, 
  Plus, 
  TrendingUp, 
  CheckCircle2, 
  AlertTriangle,
  Building2,
  Calendar,
  ExternalLink
} from 'lucide-react';

interface ContractListProps {
  onOpenDetail: (contractId: string) => void;
  onOpenNewContract: () => void;
  searchQuery: string;
}

export const ContractList: React.FC<ContractListProps> = ({ 
  onOpenDetail, 
  onOpenNewContract, 
  searchQuery 
}) => {
  const { contracts, setActiveTab } = useCLM();
  
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'value' | 'expiry' | 'title'>('expiry');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Filter logic
  const filteredContracts = contracts.filter(c => {
    if (selectedStatus !== 'all' && c.status !== selectedStatus) return false;
    if (selectedType !== 'all' && c.type !== selectedType) return false;
    if (selectedTier !== 'all' && !c.tier.includes(selectedTier)) return false;

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        c.title.toLowerCase().includes(q) ||
        c.vendorName.toLowerCase().includes(q) ||
        c.contractNumber.toLowerCase().includes(q) ||
        c.department.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Sort logic
  const sortedContracts = [...filteredContracts].sort((a, b) => {
    let factor = sortOrder === 'asc' ? 1 : -1;
    if (sortBy === 'value') {
      return (a.totalValue - b.totalValue) * factor;
    } else if (sortBy === 'expiry') {
      return (new Date(a.endDate).getTime() - new Date(b.endDate).getTime()) * factor;
    } else {
      return a.title.localeCompare(b.title) * factor;
    }
  });

  const totalSpend = contracts.reduce((acc, c) => acc + c.totalValue, 0);
  const renewalDueCount = contracts.filter(c => c.status === 'renewal_due').length;
  const signaturePendingCount = contracts.filter(c => c.status === 'out_for_signature').length;
  const activeCount = contracts.filter(c => c.status === 'active').length;

  const handleExportCSV = () => {
    const headers = ['Contract #', 'Title', 'Vendor', 'Type', 'Tier', 'Status', 'Annual Value', 'Currency', 'Start Date', 'End Date', 'Notice Days', 'Auto Renew'];
    const rows = sortedContracts.map(c => [
      `"${c.contractNumber}"`,
      `"${c.title}"`,
      `"${c.vendorName}"`,
      `"${c.type}"`,
      `"${c.tier}"`,
      `"${c.status}"`,
      c.totalValue,
      `"${c.currency}"`,
      `"${c.startDate}"`,
      `"${c.endDate}"`,
      c.noticePeriodDays,
      c.autoRenew ? 'YES' : 'NO'
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `accordiq_contracts_register_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Portfolio KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Contract Portfolio Value</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight block mt-0.5">
              ${(totalSpend / 1000).toFixed(0)}k <span className="text-xs font-normal text-slate-500">ARR</span>
            </span>
            <span className="text-[11px] text-slate-500 mt-1 block font-medium">{contracts.length} agreements total</span>
          </div>
          <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Active &amp; In Production</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-600 tracking-tight block mt-0.5">
              {activeCount} <span className="text-xs font-normal text-slate-500">contracts</span>
            </span>
            <span className="text-[11px] text-slate-500 mt-1 block font-medium">100% compliant baseline</span>
          </div>
          <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="h-5 w-5 sm:h-6 sm:w-6" />
          </div>
        </div>

        <div 
          onClick={() => setActiveTab('renewals')}
          className="bg-white border-2 border-rose-200 hover:border-rose-400 rounded-2xl p-4 sm:p-5 shadow-xs flex items-center justify-between cursor-pointer transition-all"
        >
          <div>
            <span className="text-[11px] font-bold text-rose-600 uppercase tracking-wider block">Renewal Notice Alerts</span>
            <span className="text-xl sm:text-2xl font-black text-rose-700 tracking-tight block mt-0.5">
              {renewalDueCount} <span className="text-xs font-normal text-rose-500">due now</span>
            </span>
            <span className="text-[11px] text-rose-600 mt-1 block font-medium hover:underline">Action Radar &rarr;</span>
          </div>
          <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <Clock className="h-5 w-5 sm:h-6 sm:w-6 animate-pulse" />
          </div>
        </div>

        <div 
          onClick={() => setActiveTab('docusign')}
          className="bg-white border border-slate-200 hover:border-amber-300 rounded-2xl p-4 sm:p-5 shadow-xs flex items-center justify-between cursor-pointer transition-all"
        >
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">DocuSign Envelopes</span>
            <span className="text-xl sm:text-2xl font-black text-amber-600 tracking-tight block mt-0.5">
              {signaturePendingCount} <span className="text-xs font-normal text-slate-500">signing</span>
            </span>
            <span className="text-[11px] text-slate-500 mt-1 block font-medium hover:underline">Sign Ceremony &rarr;</span>
          </div>
          <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <FileSignature className="h-5 w-5 sm:h-6 sm:w-6" />
          </div>
        </div>

      </div>

      {/* Control Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-500">Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium text-slate-700 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active &amp; Executed</option>
              <option value="renewal_due">Renewal Notice Due</option>
              <option value="out_for_signature">DocuSign Pending</option>
              <option value="legal_review">In Legal Review</option>
              <option value="procurement_review">Procurement Negotiation</option>
              <option value="pending_approval">Pending Approvals</option>
              <option value="draft">Draft</option>
              <option value="terminated">Terminated</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-500">Type:</span>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium text-slate-700 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Types</option>
              <option value="SaaS Subscription">SaaS Subscription</option>
              <option value="MSA">MSA</option>
              <option value="SOW">SOW</option>
              <option value="DPA">DPA</option>
              <option value="Vendor Agreement">Vendor Agreement</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-500">Tier:</span>
            <select
              value={selectedTier}
              onChange={(e) => setSelectedTier(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium text-slate-700 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Tiers</option>
              <option value="Tier 1">Tier 1 (Mission Critical)</option>
              <option value="Tier 2">Tier 2 (Operational)</option>
              <option value="Tier 3">Tier 3 (Commodity)</option>
            </select>
          </div>

        </div>

        {/* View Switcher, Sort & Export */}
        <div className="flex items-center gap-3">
          
          <div className="flex items-center gap-1.5 text-xs">
            <span className="font-semibold text-slate-400">Sort:</span>
            <button
              onClick={() => {
                if (sortBy === 'expiry') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                else setSortBy('expiry');
              }}
              className={`px-2.5 py-1 rounded-lg border cursor-pointer ${
                sortBy === 'expiry' ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-semibold' : 'border-slate-200 text-slate-600'
              }`}
            >
              Expiry Date {sortBy === 'expiry' && (sortOrder === 'asc' ? '↑' : '↓')}
            </button>
            <button
              onClick={() => {
                if (sortBy === 'value') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                else setSortBy('value');
              }}
              className={`px-2.5 py-1 rounded-lg border cursor-pointer ${
                sortBy === 'value' ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-semibold' : 'border-slate-200 text-slate-600'
              }`}
            >
              Value {sortBy === 'value' && (sortOrder === 'asc' ? '↑' : '↓')}
            </button>
          </div>

          <div className="h-5 w-[1px] bg-slate-200" />

          {/* Mode Switcher */}
          <div className="flex items-center border border-slate-200 rounded-lg p-0.5 bg-slate-50">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-md cursor-pointer transition-colors ${
                viewMode === 'table' ? 'bg-white shadow-xs text-indigo-600' : 'text-slate-400 hover:text-slate-700'
              }`}
              title="Table View"
            >
              <List className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md cursor-pointer transition-colors ${
                viewMode === 'grid' ? 'bg-white shadow-xs text-indigo-600' : 'text-slate-400 hover:text-slate-700'
              }`}
              title="Grid Cards View"
            >
              <Grid className="h-4 w-4" />
            </button>
          </div>

          <button
            onClick={handleExportCSV}
            className="p-2 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-lg cursor-pointer transition-colors"
            title="Export CSV Register"
          >
            <Download className="h-4 w-4" />
          </button>

        </div>

      </div>

      {/* Main Contracts View: Table or Grid */}
      {viewMode === 'table' ? (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3.5 px-4">Contract / Vendor</th>
                  <th className="py-3.5 px-4">Agreement Type</th>
                  <th className="py-3.5 px-4">Status &amp; Risk</th>
                  <th className="py-3.5 px-4">Annual Commitment</th>
                  <th className="py-3.5 px-4">Term &amp; Expiry</th>
                  <th className="py-3.5 px-4">DocuSign / Renewal</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedContracts.map((c) => (
                  <tr 
                    key={c.id} 
                    className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                    onClick={() => onOpenDetail(c.id)}
                  >
                    
                    {/* Contract Title & Vendor */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                        {c.title}
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                        <span className="font-semibold text-slate-700">{c.vendorName}</span>
                        <span>&bull;</span>
                        <span className="font-mono text-slate-400">{c.contractNumber}</span>
                      </div>
                    </td>

                    {/* Type & Tier */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{c.type}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{c.department}</div>
                    </td>

                    {/* Status & Risk */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="space-y-1">
                        <StatusBadge status={c.status} />
                        <div><RiskBadge risk={c.riskLevel} /></div>
                      </div>
                    </td>

                    {/* Value */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-extrabold text-slate-900 text-sm">
                        ${c.totalValue.toLocaleString()} {c.currency}
                      </div>
                      <div className="text-[10px] text-slate-400">{c.billingFrequency} Billing</div>
                    </td>

                    {/* Expiry */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{c.endDate}</div>
                      <div className="text-[11px] text-slate-500">
                        {c.noticePeriodDays}d notice window
                      </div>
                    </td>

                    {/* DocuSign status */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {c.envelope ? (
                        <div className="flex items-center gap-1.5">
                          <span className="h-5 w-5 rounded bg-amber-500 text-slate-950 font-bold text-[10px] flex items-center justify-center">
                            dS
                          </span>
                          <span className="font-semibold capitalize text-slate-700 text-xs">
                            {c.envelope.status}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400">Pre-Execution</span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 whitespace-nowrap text-right" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => onOpenDetail(c.id)}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-xs"
                      >
                        Open Dossier
                      </button>
                    </td>

                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Grid Cards View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {sortedContracts.map((c) => (
            <div 
              key={c.id}
              onClick={() => onOpenDetail(c.id)}
              className="bg-white border border-slate-200 hover:border-indigo-300 rounded-2xl p-5 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-slate-400">{c.contractNumber}</span>
                  <StatusBadge status={c.status} />
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900 hover:text-indigo-600 transition-colors line-clamp-2">
                    {c.title}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-1">Vendor: {c.vendorName}</p>
                </div>

                <div className="flex items-center gap-2">
                  <TierBadge tier={c.tier} />
                  <RiskBadge risk={c.riskLevel} />
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-xs text-slate-600 border border-slate-100">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Annual Run-rate:</span>
                    <span className="font-bold text-slate-900">${c.totalValue.toLocaleString()} {c.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Term Expiry:</span>
                    <span className="font-semibold text-slate-800">{c.endDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Notice Requirement:</span>
                    <span className="font-semibold text-rose-700">{c.noticePeriodDays} days</span>
                  </div>
                </div>

                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {c.summary}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-400">{c.type}</span>
                <span className="font-semibold text-indigo-600 hover:underline">View Dossier &rarr;</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {sortedContracts.length === 0 && (
        <div className="p-12 text-center bg-white rounded-2xl border border-dashed border-slate-300">
          <FileText className="h-10 w-10 text-slate-400 mx-auto mb-2" />
          <h4 className="text-sm font-semibold text-slate-700">No Contracts Found</h4>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            No contracts match your current filter parameters or search terms. Try clearing filters or create a new contract.
          </p>
        </div>
      )}

    </div>
  );
};
