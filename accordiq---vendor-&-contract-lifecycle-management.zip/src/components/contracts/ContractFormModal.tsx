import React, { useState } from 'react';
import { useCLM } from '../../context/CLMContext';
import { ContractType, ContractTier, RiskLevel } from '../../types/clm';
import { X, FileText, CheckCircle2, ShieldAlert } from 'lucide-react';

interface ContractFormModalProps {
  onClose: () => void;
}

export const ContractFormModal: React.FC<ContractFormModalProps> = ({ onClose }) => {
  const { vendors, addContract, standardClauses, currentUser } = useCLM();

  const [formData, setFormData] = useState({
    title: '',
    vendorId: vendors[0]?.id || '',
    type: 'SaaS Subscription' as ContractType,
    tier: 'Tier 1 (Mission Critical)' as ContractTier,
    riskLevel: 'medium' as RiskLevel,
    totalValue: 50000,
    currency: 'USD',
    billingFrequency: 'Annual' as any,
    department: 'Engineering' as any,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    noticePeriodDays: 60,
    autoRenew: true,
    renewalPriceCapPercent: 3.5,
    governingLaw: 'State of Delaware',
    liabilityCap: '12 months fees paid',
    legalOwner: 'Rachel Zane (Senior Corporate Counsel)',
    procurementOwner: currentUser.name,
    businessOwner: 'Alex Rivera (VP Technology)',
    summary: '',
    documentFileName: 'Master_Agreement_Executed.pdf',
    version: '1.0'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const vendor = vendors.find(v => v.id === formData.vendorId);
    if (!vendor) return;

    // Build initial clauses from standard templates
    const initialClauses = standardClauses.map((tpl, idx) => ({
      id: `cls-new-${Date.now()}-${idx}`,
      title: tpl.title,
      category: tpl.category,
      standardText: tpl.standardText,
      currentText: tpl.standardText,
      isModified: false,
      riskLevel: 'low' as RiskLevel,
      notes: tpl.notes
    }));

    // Standard approvals matrix
    const initialApprovals = [
      {
        role: 'Legal Counsel' as const,
        name: 'Rachel Zane',
        email: 'rzane@company.com',
        status: 'pending' as const
      },
      {
        role: 'Head of Procurement' as const,
        name: currentUser.name,
        email: currentUser.email,
        status: 'approved' as const,
        comments: 'Commercial terms negotiated & budgeted.',
        decidedAt: new Date().toISOString()
      },
      {
        role: 'Finance / CFO' as const,
        name: 'Sophia Chen',
        email: 'schen@company.com',
        status: 'pending' as const
      },
      {
        role: 'Business Owner' as const,
        name: formData.businessOwner,
        email: 'owner@company.com',
        status: 'pending' as const
      }
    ];

    addContract({
      ...formData,
      vendorName: vendor.name,
      status: 'legal_review',
      clauses: initialClauses,
      approvals: initialApprovals,
      notes: [
        {
          id: `not-${Date.now()}`,
          authorName: currentUser.name,
          authorRole: currentUser.role,
          timestamp: new Date().toISOString(),
          content: 'Contract initialized into Legal Review workflow.'
        }
      ]
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <FileText className="h-5 w-5 text-indigo-400" />
            <div>
              <h3 className="font-bold text-base">Register New Contract</h3>
              <p className="text-xs text-slate-400">Initiate central repository tracking &amp; renewal surveillance</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto flex-1 space-y-4">
          
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Contract Title</label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g. Datadog Infrastructure APM Enterprise Renewal"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Select Vendor</label>
              <select
                value={formData.vendorId}
                onChange={(e) => setFormData({ ...formData, vendorId: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              >
                {vendors.map(v => (
                  <option key={v.id} value={v.id}>{v.name} ({v.tier.split(' ')[0]})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Contract Agreement Type</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as ContractType })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              >
                <option value="SaaS Subscription">SaaS Subscription</option>
                <option value="MSA">Master Services Agreement (MSA)</option>
                <option value="SOW">Statement of Work (SOW)</option>
                <option value="NDA">Non-Disclosure Agreement (NDA)</option>
                <option value="DPA">Data Processing Addendum (DPA)</option>
                <option value="Vendor Agreement">Vendor Agreement</option>
                <option value="Software License">Software License</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Total Contract Value ($)</label>
              <input
                type="number"
                min="0"
                step="1000"
                required
                value={formData.totalValue}
                onChange={(e) => setFormData({ ...formData, totalValue: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Billing Frequency</label>
              <select
                value={formData.billingFrequency}
                onChange={(e) => setFormData({ ...formData, billingFrequency: e.target.value as any })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              >
                <option value="Annual">Annual</option>
                <option value="Quarterly">Quarterly</option>
                <option value="Monthly">Monthly</option>
                <option value="Milestone-based">Milestone-based</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
              <select
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value as any })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              >
                <option value="Engineering">Engineering</option>
                <option value="IT & Security">IT &amp; Security</option>
                <option value="Legal">Legal</option>
                <option value="Finance">Finance</option>
                <option value="Marketing">Marketing</option>
                <option value="Operations">Operations</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Effective Start Date</label>
              <input
                type="date"
                required
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Contract End Date</label>
              <input
                type="date"
                required
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Notice Period (Days)</label>
              <input
                type="number"
                min="0"
                max="180"
                required
                value={formData.noticePeriodDays}
                onChange={(e) => setFormData({ ...formData, noticePeriodDays: parseInt(e.target.value) || 30 })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.autoRenew}
                  onChange={(e) => setFormData({ ...formData, autoRenew: e.target.checked })}
                  className="rounded text-indigo-600 h-4 w-4"
                />
                <span>Contract Automatically Renews</span>
              </label>

              {formData.autoRenew && (
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-slate-500">Max Renewal Price Cap:</span>
                  <input
                    type="number"
                    step="0.5"
                    value={formData.renewalPriceCapPercent}
                    onChange={(e) => setFormData({ ...formData, renewalPriceCapPercent: parseFloat(e.target.value) || 0 })}
                    className="w-16 px-2 py-0.5 border border-slate-300 rounded text-xs text-right font-bold"
                  />
                  <span className="text-slate-500">%</span>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Governing Law Forum</label>
              <input
                type="text"
                value={formData.governingLaw}
                onChange={(e) => setFormData({ ...formData, governingLaw: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Liability Cap Clause</label>
              <input
                type="text"
                value={formData.liabilityCap}
                onChange={(e) => setFormData({ ...formData, liabilityCap: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Summary / Objective</label>
            <textarea
              rows={2}
              required
              value={formData.summary}
              onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
              placeholder="Describe software scope, user seat allocations, and strategic business goals..."
              className="w-full p-2.5 border border-slate-300 rounded-lg text-xs"
            />
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
            >
              Register &amp; Enforce Surveillance
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
