import React, { useState } from 'react';
import { useCLM } from '../../context/CLMContext';
import { Contract, ContractStatus } from '../../types/clm';
import { StatusBadge, RiskBadge, TierBadge, ObligationStatusBadge } from '../common/Badge';
import { DocuSignSignModal } from '../docusign/DocuSignSignModal';
import { DocuSignCertificateModal } from '../docusign/DocuSignCertificateModal';
import { 
  X, 
  FileText, 
  FileSignature, 
  Calendar, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Users, 
  Send, 
  RotateCcw, 
  Download, 
  Printer, 
  FileEdit,
  ExternalLink,
  ChevronRight,
  PenTool
} from 'lucide-react';

interface ContractDetailModalProps {
  contractId: string;
  onClose: () => void;
}

export const ContractDetailModal: React.FC<ContractDetailModalProps> = ({ contractId, onClose }) => {
  const { 
    contracts, 
    obligations, 
    auditLogs, 
    currentUser, 
    updateContractStatus, 
    createDocuSignEnvelope,
    addCollaborationNote,
    updateApprovalStatus,
    restoreClauseToStandard,
    executeAutoRenewal
  } = useCLM();

  const contract = contracts.find(c => c.id === contractId);
  const [activeTab, setActiveTab] = useState<'overview' | 'clauses' | 'obligations' | 'docusign' | 'approvals' | 'notes' | 'audit'>('overview');
  const [newNote, setNewNote] = useState('');
  const [activeSignModal, setActiveSignModal] = useState<{ envelope: any; signer: any } | null>(null);
  const [activeCertModal, setActiveCertModal] = useState<any | null>(null);

  if (!contract) return null;

  const contractObligations = obligations.filter(o => o.contractId === contract.id);
  const contractAuditLogs = auditLogs.filter(a => a.contractId === contract.id);

  // Lifecycle steps
  const steps: { key: ContractStatus; label: string }[] = [
    { key: 'draft', label: '1. Draft' },
    { key: 'legal_review', label: '2. Legal Review' },
    { key: 'procurement_review', label: '3. Procurement' },
    { key: 'pending_approval', label: '4. Approvals' },
    { key: 'out_for_signature', label: '5. DocuSign E-Sign' },
    { key: 'active', label: '6. Active' },
    { key: 'renewal_due', label: '7. Renewal Window' }
  ];

  const getStepIndex = (status: ContractStatus) => {
    switch (status) {
      case 'draft': return 0;
      case 'legal_review': return 1;
      case 'procurement_review': return 2;
      case 'pending_approval': return 3;
      case 'out_for_signature': return 4;
      case 'active': return 5;
      case 'renewal_due': return 6;
      case 'renewed': return 5;
      default: return 5;
    }
  };

  const currentStepIndex = getStepIndex(contract.status);

  const handlePostNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    addCollaborationNote(contract.id, newNote);
    setNewNote('');
  };

  const handleCreateEnvelope = () => {
    createDocuSignEnvelope(contract.id);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-5 flex items-start justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono text-xs text-indigo-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                {contract.contractNumber}
              </span>
              <StatusBadge status={contract.status} />
              <RiskBadge risk={contract.riskLevel} />
              <TierBadge tier={contract.tier} />
              <span className="text-xs text-slate-400">v{contract.version}</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold tracking-tight text-white">{contract.title}</h2>
            <p className="text-xs text-slate-400">
              Vendor: <strong className="text-white">{contract.vendorName}</strong> &bull; Total Value: <strong className="text-emerald-400">${contract.totalValue.toLocaleString()} {contract.currency}</strong> &bull; Term: {contract.startDate} to {contract.endDate}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Print Dossier"
            >
              <Printer className="h-4 w-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Lifecycle Stepper Bar */}
        <div className="bg-slate-950 px-6 py-3 border-b border-slate-800 overflow-x-auto">
          <div className="flex items-center justify-between min-w-[650px] gap-2">
            {steps.map((st, idx) => {
              const isPast = idx < currentStepIndex;
              const isCurrent = idx === currentStepIndex;

              return (
                <div key={st.key} className="flex items-center gap-2 flex-1">
                  <div className="flex items-center gap-1.5">
                    <div className={`h-6 w-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      isCurrent 
                        ? 'bg-indigo-600 text-white ring-2 ring-indigo-400 animate-pulse' 
                        : isPast 
                        ? 'bg-emerald-600 text-white' 
                        : 'bg-slate-800 text-slate-400'
                    }`}>
                      {isPast ? <CheckCircle2 className="h-3.5 w-3.5" /> : idx + 1}
                    </div>
                    <span className={`text-[11px] font-medium whitespace-nowrap ${
                      isCurrent ? 'text-white font-bold' : isPast ? 'text-slate-300' : 'text-slate-400'
                    }`}>
                      {st.label}
                    </span>
                  </div>
                  {idx < steps.length - 1 && (
                    <div className={`h-[2px] flex-1 ${isPast ? 'bg-emerald-600' : 'bg-slate-800'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-white border-b border-slate-200 px-6 flex items-center gap-6 overflow-x-auto text-xs font-semibold text-slate-500">
          {[
            { id: 'overview', label: 'Commercials & Terms' },
            { id: 'clauses', label: `Clauses & Redlines (${contract.clauses.length})` },
            { id: 'obligations', label: `Obligations & SLAs (${contractObligations.length})` },
            { id: 'docusign', label: 'DocuSign Envelope' },
            { id: 'approvals', label: 'Approvals Matrix' },
            { id: 'notes', label: `Collaboration (${contract.notes.length})` },
            { id: 'audit', label: `Audit Log (${contractAuditLogs.length})` }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3 border-b-2 whitespace-nowrap cursor-pointer transition-colors ${
                activeTab === tab.id 
                  ? 'border-indigo-600 text-indigo-600' 
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              
              {/* Executive Summary */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 text-xs">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Scope &amp; Executive Summary</span>
                <p className="text-slate-700 leading-relaxed text-sm">{contract.summary}</p>
              </div>

              {/* Key Commercial Terms Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block text-[11px] mb-1">Total Contract Value</span>
                  <span className="text-base font-bold text-slate-900">${contract.totalValue.toLocaleString()} {contract.currency}</span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">Billing: {contract.billingFrequency}</span>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block text-[11px] mb-1">Contract Duration</span>
                  <span className="font-bold text-slate-900 block">{contract.startDate} &rarr; {contract.endDate}</span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">Auto-renew: {contract.autoRenew ? 'Yes' : 'No'}</span>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block text-[11px] mb-1">Mandatory Notice Window</span>
                  <span className="font-bold text-rose-700 block text-sm">{contract.noticePeriodDays} Days Required</span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">Escalation Cap: {contract.renewalPriceCapPercent || 0}%</span>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block text-[11px] mb-1">Liability Ceiling</span>
                  <span className="font-bold text-slate-900 block">{contract.liabilityCap}</span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">Jurisdiction: {contract.governingLaw}</span>
                </div>
              </div>

              {/* Ownership & Stakeholders */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">Internal Functional Leads</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-purple-50/60 border border-purple-200 rounded-lg">
                    <span className="text-[10px] uppercase font-bold text-purple-700 block">Legal Counsel</span>
                    <span className="font-semibold text-slate-900">{contract.legalOwner}</span>
                  </div>
                  <div className="p-3 bg-sky-50/60 border border-sky-200 rounded-lg">
                    <span className="text-[10px] uppercase font-bold text-sky-700 block">Procurement Lead</span>
                    <span className="font-semibold text-slate-900">{contract.procurementOwner}</span>
                  </div>
                  <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg">
                    <span className="text-[10px] uppercase font-bold text-slate-600 block">Business Owner</span>
                    <span className="font-semibold text-slate-900">{contract.businessOwner}</span>
                  </div>
                </div>
              </div>

              {/* Attached Master PDF */}
              {contract.documentFileName && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                      PDF
                    </div>
                    <div>
                      <span className="font-bold text-slate-900 block">{contract.documentFileName}</span>
                      <span className="text-slate-500 text-[11px]">Primary Executed Agreement &bull; 2.4 MB &bull; SHA-256 Verified</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => alert(`Simulated document viewer: Downloaded ${contract.documentFileName}`)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 rounded-lg font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              )}

            </div>
          )}

          {/* TAB 2: CLAUSES & REDLINES */}
          {activeTab === 'clauses' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Key contractual provisions analyzed against corporate playbook.</span>
                <span className="text-amber-700 font-semibold">{contract.clauses.filter(c => c.isModified).length} modified clauses</span>
              </div>

              <div className="space-y-3">
                {contract.clauses.map((clause) => (
                  <div 
                    key={clause.id}
                    className={`p-4 rounded-xl border transition-all text-xs ${
                      clause.isModified ? 'bg-amber-50/30 border-amber-300' : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{clause.title}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700 font-medium">
                          {clause.category}
                        </span>
                      </div>
                      <RiskBadge risk={clause.riskLevel} />
                    </div>

                    <div className="bg-white p-3 rounded-lg border border-slate-200 font-mono text-xs leading-relaxed text-slate-800">
                      {clause.currentText}
                    </div>

                    {clause.isModified && (
                      <div className="mt-2 text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                        <span className="font-bold text-slate-600 block mb-0.5">Approved Company Standard:</span>
                        <p className="font-mono text-slate-600">{clause.standardText}</p>
                      </div>
                    )}

                    {clause.notes && (
                      <p className="mt-2 text-[11px] text-slate-500 italic">
                        <strong>Review Note:</strong> {clause.notes}
                      </p>
                    )}

                    {clause.isModified && (
                      <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
                        <button
                          onClick={() => restoreClauseToStandard(contract.id, clause.id)}
                          className="text-xs text-emerald-700 hover:text-emerald-900 font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw className="h-3 w-3" />
                          <span>Revert to Standard Playbook</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: OBLIGATIONS & SLAS */}
          {activeTab === 'obligations' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Contractual covenants and periodic compliance deliverables.</span>
                <span>{contractObligations.length} obligations registered</span>
              </div>

              <div className="space-y-3">
                {contractObligations.map((ob) => (
                  <div key={ob.id} className="p-4 bg-white border border-slate-200 rounded-xl text-xs space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ObligationStatusBadge status={ob.status} />
                        <span className="font-bold text-slate-900">{ob.title}</span>
                      </div>
                      <span className="font-semibold text-slate-700">Due: {ob.dueDate}</span>
                    </div>

                    <p className="text-slate-600 leading-relaxed">{ob.description}</p>
                    
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <span>Owner: {ob.assigneeName} ({ob.assignedRole})</span>
                      {ob.penaltyTerms && (
                        <span className="text-amber-700 font-medium">Penalty: {ob.penaltyTerms}</span>
                      )}
                    </div>
                  </div>
                ))}

                {contractObligations.length === 0 && (
                  <p className="text-center py-8 text-xs text-slate-500">No obligations logged for this contract.</p>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: DOCUSIGN STATUS */}
          {activeTab === 'docusign' && (
            <div className="space-y-4">
              {contract.envelope ? (
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50/50 border border-amber-200 rounded-xl flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-6 rounded bg-amber-600 text-white font-bold text-xs flex items-center justify-center">dS</span>
                        <h4 className="font-bold text-sm text-slate-900">DocuSign Envelope: {contract.envelope.envelopeId}</h4>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">Status: <strong className="uppercase">{contract.envelope.status}</strong></p>
                    </div>

                    {contract.envelope.status === 'completed' ? (
                      <button
                        onClick={() => setActiveCertModal(contract.envelope)}
                        className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
                      >
                        View Certificate of Completion
                      </button>
                    ) : (
                      <span className="text-xs text-amber-700 font-semibold bg-amber-100 px-3 py-1 rounded-full">
                        Ceremony in Progress
                      </span>
                    )}
                  </div>

                  {/* Signers list */}
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Signing Sequence</span>
                    {contract.envelope.signers.map(s => (
                      <div key={s.id} className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-slate-900">#{s.routingOrder} {s.name}</span>
                          <span className="text-slate-500 text-[11px] block">{s.role} &bull; {s.email}</span>
                        </div>

                        <div>
                          {s.status === 'signed' ? (
                            <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                              <CheckCircle2 className="h-3.5 w-3.5" /> Signed
                            </span>
                          ) : s.status === 'delivered' ? (
                            <button
                              onClick={() => setActiveSignModal({ envelope: contract.envelope, signer: s })}
                              className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer"
                            >
                              <PenTool className="h-3.5 w-3.5" />
                              <span>Sign Now</span>
                            </button>
                          ) : (
                            <span className="text-slate-400">Waiting</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-3">
                  <FileSignature className="h-8 w-8 text-slate-400 mx-auto" />
                  <div>
                    <h4 className="font-bold text-sm text-slate-800">DocuSign Envelope Not Yet Dispatched</h4>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                      Once internal Legal and Procurement stakeholders approve this draft, you can generate a DocuSign envelope.
                    </p>
                  </div>
                  <button
                    onClick={handleCreateEnvelope}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer"
                  >
                    Generate &amp; Dispatch DocuSign Envelope
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: APPROVALS */}
          {activeTab === 'approvals' && (
            <div className="space-y-4">
              <div className="space-y-3">
                {contract.approvals.map(app => (
                  <div key={app.role} className="p-4 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-slate-900 block">{app.role}</span>
                      <span className="text-slate-500">{app.name}</span>
                      {app.comments && <p className="text-slate-600 italic mt-1 text-[11px]">"{app.comments}"</p>}
                    </div>
                    <div>
                      {app.status === 'approved' ? (
                        <span className="text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                          Approved
                        </span>
                      ) : (
                        <span className="text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
                          Pending
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: COLLABORATION NOTES */}
          {activeTab === 'notes' && (
            <div className="space-y-4">
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {contract.notes.map(n => (
                  <div key={n.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{n.authorName} ({n.authorRole})</span>
                      <span className="text-[10px] text-slate-400">{new Date(n.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed">{n.content}</p>
                  </div>
                ))}
              </div>

              <form onSubmit={handlePostNote} className="flex gap-2">
                <input
                  type="text"
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder={`Comment as ${currentUser.name}...`}
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold cursor-pointer"
                >
                  Post Note
                </button>
              </form>
            </div>
          )}

          {/* TAB 7: AUDIT LOG */}
          {activeTab === 'audit' && (
            <div className="space-y-3">
              {contractAuditLogs.map(log => (
                <div key={log.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{log.action}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{new Date(log.timestamp).toLocaleString()}</span>
                  </div>
                  <p className="text-slate-600">{log.details}</p>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 font-mono">
                    <span>Actor: {log.actorName} ({log.actorRole})</span>
                    <span>Hash: {log.integrityHash.substring(0, 16)}...</span>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Quick Lifecycle Action:</span>
            <select
              value={contract.status}
              onChange={(e) => updateContractStatus(contract.id, e.target.value as ContractStatus, 'Manual override via dossier toolbar')}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-semibold text-slate-700 text-xs cursor-pointer"
            >
              <option value="draft">Draft</option>
              <option value="legal_review">In Legal Review</option>
              <option value="procurement_review">Procurement Negotiation</option>
              <option value="pending_approval">Pending Approval</option>
              <option value="out_for_signature">DocuSign Pending</option>
              <option value="active">Active &amp; Executed</option>
              <option value="renewal_due">Renewal Notice Due</option>
              <option value="renewed">Renewed</option>
              <option value="terminated">Terminated</option>
            </select>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
          >
            Close Dossier
          </button>
        </div>

      </div>

      {activeSignModal && (
        <DocuSignSignModal 
          envelope={activeSignModal.envelope}
          signer={activeSignModal.signer}
          onClose={() => setActiveSignModal(null)}
        />
      )}

      {activeCertModal && (
        <DocuSignCertificateModal 
          envelope={activeCertModal}
          onClose={() => setActiveCertModal(null)}
        />
      )}

    </div>
  );
};
