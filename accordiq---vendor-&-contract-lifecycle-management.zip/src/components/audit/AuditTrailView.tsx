import React, { useState } from 'react';
import { useCLM } from '../../context/CLMContext';
import { AuditLogEntry } from '../../types/clm';
import { 
  ShieldCheck, 
  Search, 
  Download, 
  Printer, 
  FileText, 
  Lock, 
  Filter,
  CheckCircle2,
  Calendar,
  User,
  Fingerprint
} from 'lucide-react';

export const AuditTrailView: React.FC = () => {
  const { auditLogs, setSelectedContractId } = useCLM();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredLogs = auditLogs.filter(log => {
    if (selectedCategory !== 'all' && log.category !== selectedCategory) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        log.action.toLowerCase().includes(q) ||
        log.actorName.toLowerCase().includes(q) ||
        (log.contractTitle && log.contractTitle.toLowerCase().includes(q)) ||
        log.details.toLowerCase().includes(q) ||
        log.integrityHash.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleExportCSV = () => {
    const headers = ['Timestamp', 'Action', 'Category', 'Contract', 'Actor', 'Role', 'IP Address', 'Integrity Hash', 'Details'];
    const rows = filteredLogs.map(log => [
      `"${log.timestamp}"`,
      `"${log.action}"`,
      `"${log.category}"`,
      `"${log.contractTitle || 'N/A'}"`,
      `"${log.actorName}"`,
      `"${log.actorRole}"`,
      `"${log.ipAddress}"`,
      `"${log.integrityHash}"`,
      `"${log.details.replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `accordiq_audit_log_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Audit Trail &amp; Governance Ledger</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
              SOX &amp; SOC 2 Ready
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Immutable, timestamped record of all contract revisions, redlines, sign-off approvals, e-signature ceremonies, and renewal actions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold shadow-xs cursor-pointer transition-colors"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer transition-colors"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Print Compliance Dossier</span>
          </button>
        </div>
      </div>

      {/* Security Assurance Banner */}
      <div className="bg-slate-900 text-slate-300 rounded-2xl p-4 sm:p-5 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Lock className="h-5 w-5" />
          </div>
          <div>
            <span className="text-white font-bold text-sm block">Non-Repudiation Sentinel Active</span>
            <span className="text-slate-400 text-[11px]">Each state change generates an asynchronous SHA-256 fingerprint bound to user IP and credentials.</span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-slate-400 font-mono text-[11px] bg-slate-950 px-3 py-2 rounded-xl border border-slate-800">
          <Fingerprint className="h-4 w-4 text-indigo-400" />
          <span>Ledger Integrity: Verified &amp; Sequential</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 flex-1 max-w-sm">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search audit trail by actor, action, or contract..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-semibold text-slate-500">Category:</span>
          {['all', 'E-Signature', 'Legal Review', 'Procurement', 'Approval', 'Renewal', 'Obligation', 'Creation'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                selectedCategory === cat 
                  ? 'bg-indigo-600 text-white font-semibold' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat === 'all' ? 'All Events' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Timestamp &amp; Actor</th>
                <th className="py-3 px-4">Event Category</th>
                <th className="py-3 px-4">Action &amp; Target Contract</th>
                <th className="py-3 px-4">Details &amp; Audit Notes</th>
                <th className="py-3 px-4">SHA-256 Digest</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                  
                  {/* Timestamp & Actor */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="font-bold text-slate-900">{log.actorName}</div>
                    <div className="text-[11px] text-slate-500">{log.actorRole}</div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                      {new Date(log.timestamp).toLocaleString()}
                    </div>
                  </td>

                  {/* Category */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold ${
                      log.category === 'E-Signature' ? 'bg-amber-50 text-amber-800 border border-amber-200' :
                      log.category === 'Legal Review' ? 'bg-purple-50 text-purple-800 border border-purple-200' :
                      log.category === 'Approval' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                      log.category === 'Renewal' ? 'bg-rose-50 text-rose-800 border border-rose-200' :
                      log.category === 'Obligation' ? 'bg-sky-50 text-sky-800 border border-sky-200' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {log.category}
                    </span>
                  </td>

                  {/* Action & Contract */}
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-900">{log.action}</div>
                    {log.contractTitle && (
                      <button
                        onClick={() => log.contractId && setSelectedContractId(log.contractId)}
                        className="text-[11px] text-indigo-600 hover:underline block truncate max-w-xs text-left cursor-pointer mt-0.5"
                      >
                        {log.contractTitle}
                      </button>
                    )}
                  </td>

                  {/* Details */}
                  <td className="py-3.5 px-4 text-slate-600 max-w-sm">
                    <p className="line-clamp-2 text-xs leading-relaxed">{log.details}</p>
                    <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">IP: {log.ipAddress}</span>
                  </td>

                  {/* Hash */}
                  <td className="py-3.5 px-4 whitespace-nowrap font-mono text-[10px] text-slate-400">
                    <span className="bg-slate-100 px-1.5 py-0.5 rounded select-all" title={log.integrityHash}>
                      {log.integrityHash.substring(0, 16)}...
                    </span>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredLogs.length === 0 && (
          <div className="text-center py-12">
            <p className="text-xs text-slate-500">No audit log records match the current filter query.</p>
          </div>
        )}
      </div>

    </div>
  );
};
