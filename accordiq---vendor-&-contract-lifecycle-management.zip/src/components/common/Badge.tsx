import React from 'react';
import { ContractStatus, RiskLevel, ContractTier } from '../../types/clm';

export const StatusBadge: React.FC<{ status: ContractStatus; size?: 'sm' | 'md' }> = ({ status, size = 'sm' }) => {
  const styles: Record<ContractStatus, { bg: string; text: string; label: string; dot: string }> = {
    draft: { bg: 'bg-slate-100', text: 'text-slate-700', label: 'Draft', dot: 'bg-slate-400' },
    legal_review: { bg: 'bg-indigo-50 border border-indigo-200', text: 'text-indigo-700', label: 'In Legal Review', dot: 'bg-indigo-500' },
    procurement_review: { bg: 'bg-sky-50 border border-sky-200', text: 'text-sky-700', label: 'Procurement Negotiation', dot: 'bg-sky-500' },
    pending_approval: { bg: 'bg-amber-50 border border-amber-200', text: 'text-amber-800', label: 'Pending Approvals', dot: 'bg-amber-500' },
    out_for_signature: { bg: 'bg-blue-50 border border-blue-300', text: 'text-blue-700', label: 'DocuSign Pending', dot: 'bg-blue-500 animate-pulse' },
    active: { bg: 'bg-emerald-50 border border-emerald-200', text: 'text-emerald-700', label: 'Active & Executed', dot: 'bg-emerald-500' },
    renewal_due: { bg: 'bg-rose-50 border border-rose-300 text-rose-700 font-semibold', text: 'text-rose-700', label: 'Renewal Notice Due', dot: 'bg-rose-500 animate-ping' },
    renewed: { bg: 'bg-teal-50 border border-teal-200', text: 'text-teal-700', label: 'Renewed', dot: 'bg-teal-500' },
    expired: { bg: 'bg-zinc-100 text-zinc-600', text: 'text-zinc-600', label: 'Expired', dot: 'bg-zinc-400' },
    terminated: { bg: 'bg-stone-100 text-stone-600', text: 'text-stone-600', label: 'Terminated', dot: 'bg-stone-400' }
  };

  const current = styles[status] || styles.draft;
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm font-medium';

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-medium ${current.bg} ${current.text} ${sizeClasses}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${current.dot}`} />
      {current.label}
    </span>
  );
};

export const RiskBadge: React.FC<{ risk: RiskLevel }> = ({ risk }) => {
  const styles: Record<RiskLevel, { bg: string; text: string; label: string }> = {
    low: { bg: 'bg-emerald-50 text-emerald-700 border border-emerald-200', text: 'text-emerald-700', label: 'Low Risk' },
    medium: { bg: 'bg-amber-50 text-amber-700 border border-amber-200', text: 'text-amber-700', label: 'Medium Risk' },
    high: { bg: 'bg-orange-50 text-orange-700 border border-orange-200', text: 'text-orange-700', label: 'High Risk' },
    critical: { bg: 'bg-rose-100 text-rose-800 border border-rose-300 font-bold', text: 'text-rose-800', label: 'Critical Risk' }
  };

  const current = styles[risk] || styles.low;
  return (
    <span className={`inline-flex items-center px-2 py-0.5 text-xs font-medium rounded ${current.bg}`}>
      {current.label}
    </span>
  );
};

export const TierBadge: React.FC<{ tier: ContractTier }> = ({ tier }) => {
  let color = 'bg-slate-100 text-slate-700';
  if (tier.includes('Tier 1')) color = 'bg-purple-50 text-purple-700 border border-purple-200 font-semibold';
  else if (tier.includes('Tier 2')) color = 'bg-blue-50 text-blue-700 border border-blue-200';

  return (
    <span className={`inline-flex items-center px-2 py-0.5 text-xs rounded ${color}`}>
      {tier}
    </span>
  );
};

export const ObligationStatusBadge: React.FC<{ status: string }> = ({ status }) => {
  switch (status) {
    case 'met':
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 rounded">Met &amp; Verified</span>;
    case 'in_progress':
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 rounded">In Progress</span>;
    case 'at_risk':
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300 rounded">At Risk</span>;
    case 'overdue':
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold bg-rose-50 text-rose-700 border border-rose-300 rounded">Overdue</span>;
    default:
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium bg-slate-100 text-slate-700 rounded">Pending</span>;
  }
};
