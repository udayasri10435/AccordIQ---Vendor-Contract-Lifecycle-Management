import React, { useState } from 'react';
import { useCLM } from '../../context/CLMContext';
import { Contract, Clause } from '../../types/clm';
import { StatusBadge, RiskBadge } from '../common/Badge';
import { 
  Users, 
  Scale, 
  Briefcase, 
  FileEdit, 
  CheckCircle2, 
  AlertOctagon, 
  RotateCcw, 
  MessageSquare, 
  Send, 
  ShieldCheck, 
  DollarSign, 
  BookOpen,
  ArrowRight,
  Filter
} from 'lucide-react';

export const CollaborationHub: React.FC = () => {
  const { 
    contracts, 
    standardClauses, 
    currentUser, 
    updateClause, 
    restoreClauseToStandard, 
    addCollaborationNote, 
    updateApprovalStatus,
    setSelectedContractId 
  } = useCLM();

  // Find contracts currently under review or having modified clauses
  const activeReviewContracts = contracts.filter(c => 
    c.status === 'legal_review' || 
    c.status === 'procurement_review' || 
    c.status === 'pending_approval' ||
    c.clauses.some(cl => cl.isModified)
  );

  const [selectedContract, setSelectedContract] = useState<Contract>(activeReviewContracts[0] || contracts[0]);
  const [activeTab, setActiveTab] = useState<'clauses' | 'approvals' | 'discussion' | 'playbook'>('clauses');
  const [commentText, setCommentText] = useState('');
  const [editingClauseId, setEditingClauseId] = useState<string | null>(null);
  const [clauseEditText, setClauseEditText] = useState('');
  const [approvalComment, setApprovalComment] = useState('');

  // Keep selectedContract synchronized with context contracts
  const currentContract = contracts.find(c => c.id === selectedContract?.id) || selectedContract;

  const handleSaveClauseEdit = (clauseId: string) => {
    updateClause(currentContract.id, clauseId, clauseEditText, 'medium', 'Revised during joint Legal & Procurement session.');
    setEditingClauseId(null);
  };

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addCollaborationNote(currentContract.id, commentText);
    setCommentText('');
  };

  const handleApproveRole = (role: string, status: 'approved' | 'changes_requested') => {
    updateApprovalStatus(currentContract.id, role, status, approvalComment || (status === 'approved' ? 'Approved based on finalized terms.' : 'Modifications requested.'));
    setApprovalComment('');
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <Users className="h-4 w-4" />
              Cross-Functional Alignment
            </div>
            <h1 className="text-2xl font-bold tracking-tight">Legal &amp; Procurement Collaboration Hub</h1>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              Bridge legal risk oversight and commercial negotiation. Redline non-standard vendor clauses, track multi-stakeholder sign-offs, and align against pre-approved corporate playbooks.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-xl backdrop-blur-xs text-xs flex items-center gap-2">
              <Scale className="h-5 w-5 text-indigo-400" />
              <div>
                <span className="text-[10px] text-slate-400 block uppercase">Legal Counsel</span>
                <span className="font-bold text-white">Rachel Zane</span>
              </div>
            </div>

            <div className="p-3 bg-white/10 rounded-xl backdrop-blur-xs text-xs flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-sky-400" />
              <div>
                <span className="text-[10px] text-slate-400 block uppercase">Procurement Lead</span>
                <span className="font-bold text-white">Marcus Sterling</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Contracts in Negotiation / Review */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Active Negotiations ({activeReviewContracts.length})
            </h3>
            <span className="text-[11px] text-slate-400">Select to review</span>
          </div>

          <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
            {activeReviewContracts.map((c) => {
              const isSelected = c.id === currentContract.id;
              const modifiedClausesCount = c.clauses.filter(cl => cl.isModified).length;

              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedContract(c)}
                  className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected 
                      ? 'bg-indigo-50/70 border-indigo-500 ring-2 ring-indigo-500/20 shadow-xs' 
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <StatusBadge status={c.status} />
                    <RiskBadge risk={c.riskLevel} />
                  </div>

                  <h4 className="text-xs font-bold text-slate-900 leading-snug">{c.title}</h4>
                  <p className="text-[11px] text-slate-500 mt-1">{c.vendorName} &bull; ${c.totalValue.toLocaleString()}</p>

                  <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">Non-standard clauses:</span>
                    <span className={`font-semibold ${modifiedClausesCount > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                      {modifiedClausesCount} flagged
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Collaboration Workspace */}
        <div className="lg:col-span-8 space-y-4">
          
          {/* Selected Contract Header Card */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-slate-400">{currentContract.contractNumber}</span>
                  <StatusBadge status={currentContract.status} />
                  <RiskBadge risk={currentContract.riskLevel} />
                </div>
                <h2 className="text-base font-bold text-slate-900 mt-1">{currentContract.title}</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Vendor: <strong className="text-slate-800">{currentContract.vendorName}</strong> &bull; Total Value: ${currentContract.totalValue.toLocaleString()} &bull; Term: {currentContract.startDate} to {currentContract.endDate}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedContractId(currentContract.id)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Full Contract Dossier
                </button>
              </div>
            </div>

            {/* Sub Tabs */}
            <div className="flex items-center gap-4 mt-4 border-b border-slate-100 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('clauses')}
                className={`pb-2.5 border-b-2 cursor-pointer transition-colors ${
                  activeTab === 'clauses' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Clause Redlines &amp; Risk ({currentContract.clauses.length})
              </button>
              <button
                onClick={() => setActiveTab('approvals')}
                className={`pb-2.5 border-b-2 cursor-pointer transition-colors ${
                  activeTab === 'approvals' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Approval Sign-Off Matrix ({currentContract.approvals.filter(a => a.status === 'approved').length}/{currentContract.approvals.length})
              </button>
              <button
                onClick={() => setActiveTab('discussion')}
                className={`pb-2.5 border-b-2 cursor-pointer transition-colors ${
                  activeTab === 'discussion' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Legal + Procurement Notes ({currentContract.notes.length})
              </button>
              <button
                onClick={() => setActiveTab('playbook')}
                className={`pb-2.5 border-b-2 cursor-pointer transition-colors ${
                  activeTab === 'playbook' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Pre-Approved Playbook
              </button>
            </div>

            {/* Tab 1: Clause Redlines */}
            {activeTab === 'clauses' && (
              <div className="pt-4 space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Compare proposed language against corporate standard playbooks.</span>
                  <span className="text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    Non-standard clauses highlighted
                  </span>
                </div>

                <div className="space-y-4">
                  {currentContract.clauses.map((clause) => {
                    const isEditing = editingClauseId === clause.id;

                    return (
                      <div 
                        key={clause.id}
                        className={`p-4 rounded-xl border transition-all ${
                          clause.isModified 
                            ? 'bg-amber-50/40 border-amber-300' 
                            : 'bg-slate-50 border-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-slate-900">{clause.title}</span>
                            <span className="text-[10px] px-2 py-0.2 rounded font-medium bg-slate-200 text-slate-700">
                              {clause.category}
                            </span>
                            {clause.isModified && (
                              <span className="text-[10px] px-2 py-0.2 rounded font-bold bg-amber-100 text-amber-800">
                                Non-Standard Redline
                              </span>
                            )}
                          </div>
                          <RiskBadge risk={clause.riskLevel} />
                        </div>

                        {/* Side-by-side or Redline block */}
                        {isEditing ? (
                          <div className="space-y-2 mt-2">
                            <textarea
                              rows={4}
                              value={clauseEditText}
                              onChange={(e) => setClauseEditText(e.target.value)}
                              className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-indigo-500"
                            />
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => setEditingClauseId(null)}
                                className="px-3 py-1 border border-slate-300 rounded text-xs text-slate-600 hover:bg-slate-100"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={() => handleSaveClauseEdit(clause.id)}
                                className="px-3 py-1 bg-indigo-600 text-white rounded text-xs font-semibold hover:bg-indigo-700"
                              >
                                Save Redline
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-3 mt-2">
                            <div className="bg-white p-3 rounded-lg border border-slate-200 text-xs">
                              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                                Current Proposed Language:
                              </span>
                              <p className={`font-mono text-xs leading-relaxed ${clause.isModified ? 'text-amber-900 font-medium' : 'text-slate-800'}`}>
                                {clause.currentText}
                              </p>
                            </div>

                            {clause.isModified && (
                              <div className="bg-slate-100/80 p-3 rounded-lg border border-slate-200 text-xs">
                                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
                                  Standard Approved Playbook Baseline:
                                </span>
                                <p className="font-mono text-xs text-slate-600 leading-relaxed">
                                  {clause.standardText}
                                </p>
                              </div>
                            )}

                            {clause.notes && (
                              <p className="text-[11px] text-slate-500 italic">
                                <strong>Legal Counsel Note:</strong> {clause.notes}
                              </p>
                            )}

                            {/* Actions on Clause */}
                            <div className="pt-2 flex items-center justify-between border-t border-slate-200/60">
                              <button
                                onClick={() => {
                                  setEditingClauseId(clause.id);
                                  setClauseEditText(clause.currentText);
                                }}
                                className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 cursor-pointer"
                              >
                                <FileEdit className="h-3.5 w-3.5" />
                                <span>Edit / Redline Clause</span>
                              </button>

                              {clause.isModified && (
                                <button
                                  onClick={() => restoreClauseToStandard(currentContract.id, clause.id)}
                                  className="text-xs text-emerald-700 hover:text-emerald-900 font-semibold flex items-center gap-1 cursor-pointer"
                                >
                                  <RotateCcw className="h-3.5 w-3.5" />
                                  <span>Inject Pre-Approved Standard</span>
                                </button>
                              )}
                            </div>
                          </div>
                        )}

                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Tab 2: Approvals Sign-off */}
            {activeTab === 'approvals' && (
              <div className="pt-4 space-y-4">
                <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl text-xs text-indigo-900">
                  <strong>Governance Requirement:</strong> Prior to releasing this contract for DocuSign execution, all 4 functional stakeholders must certify agreement.
                </div>

                <div className="space-y-3">
                  {currentContract.approvals.map((stakeholder) => (
                    <div 
                      key={stakeholder.role}
                      className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{stakeholder.role}</span>
                          <span className="text-xs text-slate-500">({stakeholder.name})</span>
                        </div>
                        {stakeholder.comments && (
                          <p className="text-xs text-slate-600 mt-1 italic">
                            "{stakeholder.comments}"
                          </p>
                        )}
                        {stakeholder.decidedAt && (
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            Decided: {new Date(stakeholder.decidedAt).toLocaleString()}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {stakeholder.status === 'approved' ? (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="h-3.5 w-3.5" /> Approved
                          </span>
                        ) : stakeholder.status === 'changes_requested' ? (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300">
                            Changes Requested
                          </span>
                        ) : (
                          <span className="text-xs text-slate-500 bg-slate-200 px-3 py-1 rounded-full">
                            Pending Review
                          </span>
                        )}

                        {/* Sign-off button as current user */}
                        <div className="flex items-center gap-1 ml-2">
                          <button
                            onClick={() => handleApproveRole(stakeholder.role, 'approved')}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold cursor-pointer"
                          >
                            Sign Off
                          </button>
                          <button
                            onClick={() => handleApproveRole(stakeholder.role, 'changes_requested')}
                            className="px-2.5 py-1 bg-slate-200 hover:bg-amber-100 hover:text-amber-800 text-slate-700 rounded text-xs font-medium cursor-pointer"
                          >
                            Request Changes
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tab 3: Discussion Thread */}
            {activeTab === 'discussion' && (
              <div className="pt-4 space-y-4">
                <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                  {currentContract.notes.map((note) => (
                    <div 
                      key={note.id}
                      className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                            note.authorRole === 'Legal' 
                              ? 'bg-purple-100 text-purple-800' 
                              : note.authorRole === 'Procurement' 
                              ? 'bg-sky-100 text-sky-800' 
                              : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {note.authorRole}
                          </span>
                          <span className="font-bold text-slate-900">{note.authorName}</span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {new Date(note.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-slate-700 leading-relaxed pt-1">{note.content}</p>
                    </div>
                  ))}

                  {currentContract.notes.length === 0 && (
                    <p className="text-center py-6 text-xs text-slate-400">
                      No notes yet. Start a discussion between Legal and Procurement below.
                    </p>
                  )}
                </div>

                <form onSubmit={handlePostComment} className="pt-2 flex items-center gap-2">
                  <input
                    type="text"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder={`Post comment as ${currentUser.name} (${currentUser.role})...`}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>Post</span>
                  </button>
                </form>
              </div>
            )}

            {/* Tab 4: Pre-Approved Playbook */}
            {activeTab === 'playbook' && (
              <div className="pt-4 space-y-3">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600">
                  These boilerplate clauses have been certified by General Counsel and may be inserted without requiring secondary outside counsel sign-off.
                </div>

                <div className="space-y-2">
                  {standardClauses.map((clause) => (
                    <div key={clause.id} className="p-3 bg-white border border-slate-200 rounded-lg text-xs">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-slate-900">{clause.title}</span>
                        <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded font-semibold">
                          Certified Safe
                        </span>
                      </div>
                      <p className="font-mono text-[11px] text-slate-600">{clause.standardText}</p>
                      <p className="text-[10px] text-slate-400 mt-1 font-sans">{clause.notes}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
};
