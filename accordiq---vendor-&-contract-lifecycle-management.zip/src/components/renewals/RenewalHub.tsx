import React, { useState } from 'react';
import { useCLM } from '../../context/CLMContext';
import { Contract } from '../../types/clm';
import { StatusBadge, RiskBadge } from '../common/Badge';
import { 
  Clock, 
  AlertTriangle, 
  Calendar, 
  DollarSign, 
  RotateCw, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  TrendingUp, 
  Send, 
  Copy,
  Printer,
  X,
  ArrowRight
} from 'lucide-react';

export const RenewalHub: React.FC = () => {
  const { 
    contracts, 
    initiateRenegotiation, 
    issueNonRenewalNotice, 
    executeAutoRenewal,
    setSelectedContractId 
  } = useCLM();

  const [activeModal, setActiveModal] = useState<{
    type: 'renegotiate' | 'terminate' | 'renew';
    contract: Contract;
  } | null>(null);

  const [actionNotes, setActionNotes] = useState('');
  const [escalationRate, setEscalationRate] = useState(3.0);
  const [copiedLetter, setCopiedLetter] = useState(false);

  // Group contracts by renewal urgency (current simulated date is late 2026)
  const now = new Date('2026-09-28');

  const contractsWithDaysLeft = contracts.map(c => {
    const end = new Date(c.endDate);
    const diffTime = end.getTime() - now.getTime();
    const daysUntilExpiry = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    // Notice deadline is (endDate - noticePeriodDays)
    const noticeDeadline = new Date(end);
    noticeDeadline.setDate(end.getDate() - c.noticePeriodDays);
    const daysUntilNoticeDeadline = Math.ceil((noticeDeadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    return {
      ...c,
      daysUntilExpiry,
      daysUntilNoticeDeadline
    };
  });

  // Buckets
  const urgentRenewals = contractsWithDaysLeft.filter(c => c.daysUntilNoticeDeadline <= 30 && c.status !== 'terminated' && c.status !== 'renewed');
  const upcomingRenewals = contractsWithDaysLeft.filter(c => c.daysUntilNoticeDeadline > 30 && c.daysUntilNoticeDeadline <= 60 && c.status !== 'terminated');
  const radarRenewals = contractsWithDaysLeft.filter(c => c.daysUntilNoticeDeadline > 60 && c.daysUntilNoticeDeadline <= 120 && c.status !== 'terminated');

  // Total annual spend at risk in next 60 days
  const spendAtRisk = [...urgentRenewals, ...upcomingRenewals].reduce((acc, c) => acc + c.totalValue, 0);

  const handleOpenAction = (type: 'renegotiate' | 'terminate' | 'renew', contract: Contract) => {
    setActiveModal({ type, contract });
    setActionNotes('');
    setEscalationRate(contract.renewalPriceCapPercent || 3.0);
  };

  const handleConfirmAction = () => {
    if (!activeModal) return;
    const { type, contract } = activeModal;

    if (type === 'renegotiate') {
      initiateRenegotiation(contract.id, actionNotes || 'Procurement initiated renewal price renegotiation to eliminate non-standard price escalators.');
    } else if (type === 'terminate') {
      issueNonRenewalNotice(contract.id, actionNotes || 'Formal notice of non-renewal submitted pursuant to Agreement termination notice provisions.');
    } else if (type === 'renew') {
      executeAutoRenewal(contract.id, escalationRate);
    }

    setActiveModal(null);
  };

  const generateTerminationLetter = (contract: Contract) => {
    return `DATE: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}

TO:
${contract.vendorName}
Attn: Legal & Contracts Department

FROM:
AccordIQ Enterprise Procurement & Legal Services
100 Innovation Way, Suite 400

SUBJECT: FORMAL NOTICE OF CONTRACT NON-RENEWAL - ${contract.contractNumber}

Dear Vendor Contracts Team,

Please accept this letter as formal written notice pursuant to Section ${contract.noticePeriodDays}-Day Notice of the ${contract.title} (Contract Reference: ${contract.contractNumber}, effective date: ${contract.startDate}) that our organization will NOT be renewing the aforementioned agreement beyond its current expiration date of ${contract.endDate}.

In accordance with the terms of the Agreement, all recurring subscription charges and automatic rollover provisions are hereby terminated effective as of ${contract.endDate}. 

Please coordinate with our procurement lead to initiate transition assistance and confirm deletion/return of confidential information as prescribed by the governing contract.

Sincerely,

Marcus Sterling, Head of Strategic Sourcing
Rachel Zane, Senior Corporate Counsel`;
  };

  const handleCopyLetter = (contract: Contract) => {
    const letter = generateTerminationLetter(contract);
    navigator.clipboard.writeText(letter);
    setCopiedLetter(true);
    setTimeout(() => setCopiedLetter(false), 3000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Proactive Renewal Radar</h1>
            <span className="px-2 py-0.5 rounded text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
              Notice Window Sentinel
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Automated tracking of mandatory non-renewal notice windows, price escalators, and strategic sourcing decisions.
          </p>
        </div>

        {/* Spend Metric */}
        <div className="bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-xs flex items-center gap-4">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Spend Under Decision</span>
            <span className="text-lg font-bold text-slate-900">${(spendAtRisk / 1000).toFixed(0)}k <span className="text-xs font-normal text-slate-500">at risk</span></span>
          </div>
          <div className="h-8 w-[1px] bg-slate-200" />
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Critical Notice Deadlines</span>
            <span className="text-lg font-bold text-rose-600">{urgentRenewals.length} contracts</span>
          </div>
        </div>
      </div>

      {/* Urgent Renewals Card Deck */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <span className="h-2.5 w-2.5 rounded-full bg-rose-500 animate-ping" />
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Critical Notice Deadlines (&lt; 30 Days Left to Give Notice)
          </h2>
        </div>

        <div className="space-y-3">
          {urgentRenewals.map((contract) => (
            <div 
              key={contract.id}
              className="bg-white border-2 border-rose-200 hover:border-rose-400 rounded-2xl p-5 shadow-xs transition-all relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 bg-rose-600 text-white text-[10px] font-bold px-3 py-1 rounded-bl-xl uppercase tracking-wider flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                Action Required
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
                
                {/* Details */}
                <div className="lg:col-span-5 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <StatusBadge status={contract.status} />
                    <span className="text-xs font-mono text-slate-400">{contract.contractNumber}</span>
                  </div>
                  <h3 
                    onClick={() => setSelectedContractId(contract.id)}
                    className="text-base font-bold text-slate-900 hover:text-indigo-600 cursor-pointer"
                  >
                    {contract.title}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Vendor: <strong className="text-slate-700">{contract.vendorName}</strong> &bull; Dept: {contract.department}
                  </p>
                </div>

                {/* Deadlines & Financials */}
                <div className="lg:col-span-4 grid grid-cols-2 gap-3 text-xs bg-rose-50/50 p-3 rounded-xl border border-rose-100">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Notice Window Closes</span>
                    <span className="font-bold text-rose-700 text-sm">
                      {contract.daysUntilNoticeDeadline <= 0 ? 'WINDOW CLOSED' : `${contract.daysUntilNoticeDeadline} Days Left`}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      ({contract.noticePeriodDays} days notice required)
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[11px]">Contract Expiry</span>
                    <span className="font-bold text-slate-800 text-sm">{contract.endDate}</span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      Annual: ${contract.totalValue.toLocaleString()}
                    </span>
                  </div>

                  <div className="col-span-2 pt-2 border-t border-rose-200/60 flex items-center justify-between text-[11px]">
                    <span className="text-slate-600">Auto-Renew Price Escalation:</span>
                    <span className="font-semibold text-rose-800">
                      +{contract.renewalPriceCapPercent || 5.0}% (+${Math.round(contract.totalValue * ((contract.renewalPriceCapPercent || 5.0) / 100)).toLocaleString()})
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="lg:col-span-3 flex flex-col gap-2">
                  <button
                    onClick={() => handleOpenAction('renegotiate', contract)}
                    className="w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer transition-colors"
                  >
                    <RotateCw className="h-3.5 w-3.5" />
                    <span>Initiate Renegotiation</span>
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleOpenAction('terminate', contract)}
                      className="py-1.5 px-2 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-300 border border-slate-200 text-slate-700 rounded-lg text-xs font-medium flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      <XCircle className="h-3.5 w-3.5" />
                      <span>Issue Notice</span>
                    </button>
                    <button
                      onClick={() => handleOpenAction('renew', contract)}
                      className="py-1.5 px-2 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 border border-slate-200 text-slate-700 rounded-lg text-xs font-medium flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>Auto-Renew</span>
                    </button>
                  </div>
                </div>

              </div>
            </div>
          ))}

          {urgentRenewals.length === 0 && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-xs flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 text-emerald-600 flex-shrink-0" />
              <div>
                <strong>All Critical Windows Addressed:</strong> No contracts currently in the &lt; 30-day notice danger zone.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Upcoming & In Radar Renewals Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Upcoming Renewal Pipeline (30 - 120 Days)</h3>
            <p className="text-xs text-slate-500">Contracts approaching strategic review milestone</p>
          </div>
          <span className="text-xs font-semibold text-slate-500">
            {upcomingRenewals.length + radarRenewals.length} active agreements
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Contract / Vendor</th>
                <th className="py-3 px-4">Expiry Date</th>
                <th className="py-3 px-4">Notice Window</th>
                <th className="py-3 px-4">Annual Spend</th>
                <th className="py-3 px-4">Price Escalation Cap</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[...upcomingRenewals, ...radarRenewals].map((contract) => (
                <tr key={contract.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4">
                    <div 
                      onClick={() => setSelectedContractId(contract.id)}
                      className="font-bold text-slate-900 hover:text-indigo-600 cursor-pointer"
                    >
                      {contract.title}
                    </div>
                    <div className="text-slate-500 text-[11px]">{contract.vendorName} &bull; {contract.type}</div>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-800">
                    {contract.endDate}
                    <span className="block text-[10px] text-slate-400">{contract.daysUntilExpiry} days left</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                      {contract.daysUntilNoticeDeadline} days notice margin
                    </span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">({contract.noticePeriodDays} days formal clause)</span>
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    ${contract.totalValue.toLocaleString()} {contract.currency}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-semibold text-slate-700">
                      {contract.autoRenew ? `Auto (${contract.renewalPriceCapPercent || 3}% cap)` : 'Manual Expiry'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleOpenAction('renegotiate', contract)}
                      className="px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:text-indigo-900 hover:bg-indigo-50 rounded transition-colors cursor-pointer"
                    >
                      Plan Renewal &rarr;
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Action Modal (Renegotiate, Terminate, or Auto-Renew) */}
      {activeModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base">
                  {activeModal.type === 'renegotiate' && 'Initiate Contract Renegotiation'}
                  {activeModal.type === 'terminate' && 'Generate Formal Non-Renewal / Termination Notice'}
                  {activeModal.type === 'renew' && 'Execute 12-Month Contract Renewal'}
                </h3>
                <p className="text-xs text-slate-300 font-mono mt-0.5">{activeModal.contract.contractNumber}</p>
              </div>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white p-1 rounded cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
                <span className="font-semibold text-slate-900 block">{activeModal.contract.title}</span>
                <span className="text-slate-500">Vendor: {activeModal.contract.vendorName} &bull; Current Term Expiry: {activeModal.contract.endDate}</span>
              </div>

              {activeModal.type === 'renegotiate' && (
                <div className="space-y-3">
                  <label className="block text-xs font-semibold text-slate-700">Procurement Renegotiation Objective / Notes</label>
                  <textarea
                    rows={4}
                    value={actionNotes}
                    onChange={(e) => setActionNotes(e.target.value)}
                    placeholder="Enter negotiation goals (e.g. Target 12% price reduction, eliminate non-standard CPI compounding escalator, add 50 user seats at no extra charge)..."
                    className="w-full p-3 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-500">
                    This will transition contract status to "Procurement Negotiation" and notify Marcus Sterling &amp; Rachel Zane.
                  </p>
                </div>
              )}

              {activeModal.type === 'terminate' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-700">Generated Legal Notice Letter</label>
                    <button
                      onClick={() => handleCopyLetter(activeModal.contract)}
                      className="text-xs text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer font-medium"
                    >
                      <Copy className="h-3.5 w-3.5" />
                      <span>{copiedLetter ? 'Copied to Clipboard!' : 'Copy Letter'}</span>
                    </button>
                  </div>
                  <pre className="p-3 bg-slate-900 text-slate-200 text-[11px] font-mono rounded-lg h-44 overflow-y-auto whitespace-pre-wrap select-all border border-slate-800">
                    {generateTerminationLetter(activeModal.contract)}
                  </pre>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Termination Notes / Sourcing Replacement</label>
                    <input
                      type="text"
                      value={actionNotes}
                      onChange={(e) => setActionNotes(e.target.value)}
                      placeholder="e.g. Replacing with Snowflake native features; non-renewal notice served."
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              )}

              {activeModal.type === 'renew' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Price Escalation Percentage applied</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="number"
                        step="0.5"
                        min="0"
                        max="20"
                        value={escalationRate}
                        onChange={(e) => setEscalationRate(parseFloat(e.target.value) || 0)}
                        className="w-32 px-3 py-1.5 border border-slate-300 rounded-lg text-sm font-semibold"
                      />
                      <span className="text-xs text-slate-500">% annual rate escalation</span>
                    </div>
                  </div>

                  <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl text-xs space-y-1.5">
                    <div className="flex justify-between text-slate-700">
                      <span>Prior Term Value:</span>
                      <span className="font-semibold">${activeModal.contract.totalValue.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-indigo-900 font-bold text-sm pt-1 border-t border-indigo-200">
                      <span>New 12-Month Term Value:</span>
                      <span>${Math.round(activeModal.contract.totalValue * (1 + escalationRate / 100)).toLocaleString()}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 block">
                      Contract end date will automatically advance by 1 full calendar year.
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                onClick={() => setActiveModal(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmAction}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Confirm &amp; Log Audit Action
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
