import React from 'react';
import { DocuSignEnvelope } from '../../types/clm';
import { 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  Printer, 
  Download, 
  FileCheck2,
  Calendar,
  Lock,
  Globe
} from 'lucide-react';

interface DocuSignCertificateModalProps {
  envelope: DocuSignEnvelope;
  onClose: () => void;
}

export const DocuSignCertificateModal: React.FC<DocuSignCertificateModalProps> = ({ envelope, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Certificate Header */}
        <div className="bg-slate-900 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-amber-500 text-slate-950 font-black flex items-center justify-center text-xl">
              d<span className="text-white">S</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg tracking-tight">DocuSign Certificate of Completion</h3>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-2 py-0.5 rounded-full font-medium">
                  {envelope.status === 'completed' ? 'Completed & Legally Binding' : 'In Progress'}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">Envelope ID: {envelope.envelopeId}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={handlePrint}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Print Certificate"
            >
              <Printer className="h-4 w-4" />
              <span className="hidden sm:inline">Print</span>
            </button>
            <button 
              onClick={onClose}
              className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Certificate details */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">

          {/* Envelope Summary Matrix */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs">
            <div>
              <span className="text-slate-500 block mb-0.5">Envelope Status</span>
              <span className="font-bold uppercase text-slate-900">{envelope.status}</span>
            </div>
            <div>
              <span className="text-slate-500 block mb-0.5">Envelope Created</span>
              <span className="font-medium text-slate-800">{new Date(envelope.createdDate).toLocaleDateString()}</span>
            </div>
            <div>
              <span className="text-slate-500 block mb-0.5">Completed Date</span>
              <span className="font-medium text-slate-800">
                {envelope.completedDate ? new Date(envelope.completedDate).toLocaleDateString() : 'Awaiting Signers'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block mb-0.5">Total Documents</span>
              <span className="font-medium text-slate-800">{envelope.totalDocuments} Attached (PDF)</span>
            </div>
          </div>

          {/* Cryptographic SHA-256 Checksum */}
          <div className="p-3.5 bg-slate-900 text-slate-300 rounded-xl border border-slate-800 font-mono text-xs flex items-start gap-3">
            <Lock className="h-4 w-4 text-emerald-400 mt-0.5 flex-shrink-0" />
            <div className="overflow-hidden">
              <span className="text-slate-400 text-[11px] block uppercase tracking-wider font-sans font-semibold">
                Tamper-Evident SHA-256 Digital Fingerprint
              </span>
              <span className="text-emerald-400 break-all text-[11px] font-mono select-all">
                {envelope.certificateHash || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}
              </span>
            </div>
          </div>

          {/* Signer Events */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">Signer Events &amp; Audit Verification</h4>
            <div className="space-y-3">
              {envelope.signers.map((signer, index) => (
                <div 
                  key={signer.id}
                  className="border border-slate-200 rounded-xl p-4 bg-white hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="h-5 w-5 rounded-full bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center">
                          {signer.routingOrder}
                        </span>
                        <span className="font-bold text-slate-900 text-sm">{signer.name}</span>
                        <span className="text-xs text-slate-500">({signer.email})</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5 ml-7">Role: {signer.role}</p>
                    </div>

                    <div>
                      {signer.status === 'signed' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Signed &amp; Verified
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200">
                          Pending Signature
                        </span>
                      )}
                    </div>
                  </div>

                  {signer.status === 'signed' && (
                    <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs ml-7">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Timestamp</span>
                        <span className="text-slate-700 font-medium">{new Date(signer.signedAt || '').toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">IP Address</span>
                        <span className="text-slate-700 font-mono text-[11px]">{signer.ipAddress || '198.51.100.42'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Signature Method</span>
                        <span className="text-slate-700 capitalize font-medium">{signer.signatureType || 'Digital Key'} Adopted</span>
                      </div>
                    </div>
                  )}

                  {signer.signatureImage && (
                    <div className="mt-2 ml-7 p-2 bg-slate-50 rounded-lg inline-block border border-slate-200">
                      <span className="text-[10px] text-slate-400 block mb-1">Adopted Digital Mark:</span>
                      <img src={signer.signatureImage} alt="Adopted signature" className="h-8 max-w-xs object-contain" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Regulatory compliance banner */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs text-slate-600">
            <h5 className="font-semibold text-slate-800 mb-1 flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              Legal Compliance Certification
            </h5>
            <p>
              This certificate verifies that electronic signatures contained within this envelope were executed in compliance with the Electronic Signatures in Global and National Commerce Act (ESIGN, 15 U.S.C. § 7001 et seq.) and the Uniform Electronic Transactions Act (UETA). All signer authentication events, timestamps, and IP addresses have been recorded with cryptographic non-repudiation.
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-4 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
          >
            Close Certificate
          </button>
        </div>

      </div>
    </div>
  );
};
