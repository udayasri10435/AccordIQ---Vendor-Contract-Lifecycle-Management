import React, { useRef, useState, useEffect } from 'react';
import { DocuSignEnvelope, DocuSignSigner } from '../../types/clm';
import { useCLM } from '../../context/CLMContext';
import { 
  X, 
  PenTool, 
  Type, 
  RotateCcw, 
  ShieldCheck, 
  CheckCircle2, 
  FileText,
  FileCheck2
} from 'lucide-react';

interface DocuSignSignModalProps {
  envelope: DocuSignEnvelope;
  signer: DocuSignSigner;
  onClose: () => void;
}

export const DocuSignSignModal: React.FC<DocuSignSignModalProps> = ({ envelope, signer, onClose }) => {
  const { signDocuSignEnvelope } = useCLM();
  const [mode, setMode] = useState<'draw' | 'type'>('type');
  const [typedName, setTypedName] = useState(signer.name);
  const [selectedFont, setSelectedFont] = useState<'font1' | 'font2' | 'font3'>('font1');
  const [agreedToTerms, setAgreedToTerms] = useState(true);

  // Canvas drawing state
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);

  useEffect(() => {
    if (mode === 'draw' && canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
      }
    }
  }, [mode]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('clientX' in e ? e.clientX : e.touches[0].clientX) - rect.left;
    const y = ('clientY' in e ? e.clientY : e.touches[0].clientY) - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
    setHasDrawn(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('clientX' in e ? e.clientX : e.touches[0].clientX) - rect.left;
    const y = ('clientY' in e ? e.clientY : e.touches[0].clientY) - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
  };

  const handleAdoptAndSign = () => {
    if (!agreedToTerms) return;

    let signatureDataUrl = '';
    if (mode === 'draw' && canvasRef.current) {
      signatureDataUrl = canvasRef.current.toDataURL('image/png');
    } else {
      // Generate canvas representation of typed signature
      const offscreen = document.createElement('canvas');
      offscreen.width = 400;
      offscreen.height = 120;
      const ctx = offscreen.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#0f172a';
        ctx.font = selectedFont === 'font1' ? 'italic 36px "Caveat", cursive, sans-serif' : 'italic 34px Georgia, serif';
        ctx.fillText(typedName, 20, 70);
        signatureDataUrl = offscreen.toDataURL('image/png');
      }
    }

    signDocuSignEnvelope(envelope.envelopeId, signer.id, signatureDataUrl, mode === 'draw' ? 'drawn' : 'typed');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* DocuSign Header */}
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-black/20 flex items-center justify-center font-black text-lg">
              d<span className="text-yellow-200">S</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base tracking-tight">DocuSign Electronic Signature</h3>
                <span className="bg-black/20 text-xs px-2 py-0.5 rounded-full font-mono text-amber-100">
                  {envelope.envelopeId}
                </span>
              </div>
              <p className="text-xs text-amber-100 font-medium">Recipient: {signer.name} ({signer.role})</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-amber-100 hover:text-white p-1 rounded-lg hover:bg-black/10 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Contract Title Banner */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-700">
            <FileText className="h-4 w-4 text-indigo-600" />
            <span className="font-semibold text-slate-900 truncate max-w-md">{envelope.contractTitle}</span>
          </div>
          <span className="text-xs text-slate-500">Signing Order: #{signer.routingOrder}</span>
        </div>

        {/* Content body */}
        <div className="p-6 space-y-6">

          {/* Mode Switcher */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setMode('type')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  mode === 'type' 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Type className="h-3.5 w-3.5" />
                <span>Select Style (Type)</span>
              </button>
              <button
                onClick={() => setMode('draw')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  mode === 'draw' 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <PenTool className="h-3.5 w-3.5" />
                <span>Draw Signature</span>
              </button>
            </div>

            {mode === 'draw' && (
              <button 
                onClick={clearCanvas}
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="h-3 w-3" />
                Clear Pad
              </button>
            )}
          </div>

          {/* Type Mode */}
          {mode === 'type' ? (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Legal Name</label>
                <input 
                  type="text"
                  value={typedName}
                  onChange={(e) => setTypedName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">Signature Preview &amp; Style</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div 
                    onClick={() => setSelectedFont('font1')}
                    className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${
                      selectedFont === 'font1' 
                        ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-500/20' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <span className="text-xs font-medium text-slate-400 block mb-1">Cursive Modern</span>
                    <div className="text-2xl italic font-serif text-slate-900 tracking-wide py-2 truncate">
                      {typedName || signer.name}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono mt-1">Initials: {typedName.split(' ').map(n => n[0]).join('')}</div>
                  </div>

                  <div 
                    onClick={() => setSelectedFont('font2')}
                    className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${
                      selectedFont === 'font2' 
                        ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-500/20' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <span className="text-xs font-medium text-slate-400 block mb-1">Executive Formal</span>
                    <div className="text-2xl font-serif text-slate-900 tracking-wider py-2 truncate">
                      {typedName || signer.name}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono mt-1">Initials: {typedName.split(' ').map(n => n[0]).join('')}</div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Draw Mode */
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700">Draw Your Signature with Mouse or Touchpad</label>
              <div className="border-2 border-dashed border-slate-300 rounded-xl bg-slate-50/50 relative overflow-hidden">
                <canvas
                  ref={canvasRef}
                  width={580}
                  height={150}
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  onTouchStart={startDrawing}
                  onTouchMove={draw}
                  onTouchEnd={stopDrawing}
                  className="w-full h-[150px] cursor-crosshair touch-none"
                />
                {!hasDrawn && (
                  <div className="absolute inset-0 pointer-events-none flex items-center justify-center text-xs text-slate-400 font-medium">
                    Sign on the line above
                  </div>
                )}
                {/* Yellow sticky signature tag mockup */}
                <div className="absolute left-4 bottom-3 bg-amber-400 text-slate-950 font-bold text-[10px] uppercase px-2 py-0.5 shadow-xs rounded-xs flex items-center gap-1 pointer-events-none">
                  <span>Sign</span>
                  <span>&rarr;</span>
                </div>
              </div>
            </div>
          )}

          {/* Legal E-Sign Act Consent Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs text-slate-600 flex items-start gap-3">
            <input 
              type="checkbox"
              id="esign-consent"
              checked={agreedToTerms}
              onChange={(e) => setAgreedToTerms(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
            />
            <label htmlFor="esign-consent" className="cursor-pointer select-none">
              <span className="font-semibold text-slate-800">Electronic Record and Signature Disclosure: </span>
              By clicking Adopt and Sign, I agree that the signature and initials will be the electronic representation of my signature for all purposes when I use them on documents, pursuant to the U.S. Electronic Signatures in Global and National Commerce Act (E-SIGN) and UETA.
            </label>
          </div>

        </div>

        {/* Footer actions */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="h-4 w-4 text-emerald-600" />
            <span>256-bit SSL encrypted &amp; audit timestamped</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleAdoptAndSign}
              disabled={!agreedToTerms || (mode === 'draw' && !hasDrawn)}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-bold text-white shadow-md transition-all cursor-pointer ${
                !agreedToTerms || (mode === 'draw' && !hasDrawn)
                  ? 'bg-slate-300 cursor-not-allowed text-slate-500'
                  : 'bg-amber-600 hover:bg-amber-700 hover:shadow-lg'
              }`}
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>Adopt &amp; Sign</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
