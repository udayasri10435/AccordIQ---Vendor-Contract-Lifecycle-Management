import React, { useState } from 'react';
import { useCLM } from '../../context/CLMContext';
import { DocuSignEnvelope, DocuSignSigner } from '../../types/clm';
import { DocuSignSignModal } from './DocuSignSignModal';
import { DocuSignCertificateModal } from './DocuSignCertificateModal';
import { 
  FileSignature, 
  Send, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  FileCheck2, 
  ShieldCheck, 
  Mail, 
  ExternalLink,
  PenTool,
  Search,
  Filter
} from 'lucide-react';

export const DocuSignCenter: React.FC = () => {
  const { contracts, currentUser, sendDocuSignReminder, setSelectedContractId } = useCLM();
  
  // Extract all envelopes from contracts
  const envelopes: DocuSignEnvelope[] = contracts
    .filter(c => c.envelope)
    .map(c => c.envelope as DocuSignEnvelope);

  const [activeSignModal, setActiveSignModal] = useState<{ envelope: DocuSignEnvelope; signer: DocuSignSigner } | null>(null);
  const [activeCertModal, setActiveCertModal] = useState<DocuSignEnvelope | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [reminderSentFor, setReminderSentFor] = useState<string | null>(null);

  const handleReminder = (envelopeId: string, signerId: string) => {
    sendDocuSignReminder(envelopeId, signerId);
    setReminderSentFor(signerId);
    setTimeout(() => setReminderSentFor(null), 3000);
  };

  const filteredEnvelopes = envelopes.filter(env => {
    if (filterStatus === 'all') return true;
    return env.status === filterStatus;
  });

  const completedCount = envelopes.filter(e => e.status === 'completed').length;
  const inProgressCount = envelopes.filter(e => e.status === 'sent' || e.status === 'delivered').length;

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-slate-900 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-6 opacity-10 pointer-events-none">
          <FileSignature className="w-64 h-64 text-white" />
        </div>
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-amber-200 text-xs font-semibold uppercase tracking-wider mb-3">
            <ShieldCheck className="h-4 w-4" />
            DocuSign E-Signature Integration
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">DocuSign Envelope Hub</h1>
          <p className="mt-2 text-slate-200 text-sm leading-relaxed">
            Manage multi-party signing ceremonies, track sequential routing orders across Legal and Vendor executives, and inspect tamper-proof Certificates of Completion.
          </p>

          <div className="mt-6 flex flex-wrap gap-4 text-xs">
            <div className="bg-white/10 backdrop-blur-md px-3.5 py-2 rounded-xl flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <span><strong>{completedCount}</strong> Executed Envelopes</span>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-3.5 py-2 rounded-xl flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-300" />
              <span><strong>{inProgressCount}</strong> In-Flight Ceremonies</span>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-3.5 py-2 rounded-xl flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>DocuSign Webhook Listener Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Status:</span>
          {['all', 'delivered', 'sent', 'completed'].map(status => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize cursor-pointer transition-colors ${
                filterStatus === status 
                  ? 'bg-amber-600 text-white font-semibold' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {status === 'all' ? 'All Envelopes' : status}
            </button>
          ))}
        </div>

        <span className="text-xs text-slate-500 font-medium">
          Showing {filteredEnvelopes.length} envelope{filteredEnvelopes.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Envelopes Grid */}
      <div className="space-y-4">
        {filteredEnvelopes.map((envelope) => {
          const totalSigners = envelope.signers.length;
          const signedCount = envelope.signers.filter(s => s.status === 'signed').length;
          const progressPercent = Math.round((signedCount / totalSigners) * 100);

          return (
            <div 
              key={envelope.id}
              className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:border-amber-300 hover:shadow-md transition-all"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                
                {/* Envelope Main Info */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2.5">
                    <div className="h-8 w-8 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center font-bold text-xs">
                      d<span className="text-amber-500">S</span>
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900 hover:text-indigo-600 cursor-pointer" onClick={() => setSelectedContractId(envelope.contractId)}>
                        {envelope.contractTitle}
                      </h3>
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-[11px] text-slate-600">
                          {envelope.envelopeId}
                        </span>
                        <span>&bull;</span>
                        <span>Sent: {envelope.sentDate ? new Date(envelope.sentDate).toLocaleDateString() : 'Draft'}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Progress & Certificate Button */}
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-xs font-semibold text-slate-700">
                      {signedCount} of {totalSigners} Signatures ({progressPercent}%)
                    </div>
                    <div className="w-36 bg-slate-100 h-2 rounded-full mt-1.5 overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all ${
                          envelope.status === 'completed' ? 'bg-emerald-500' : 'bg-amber-500'
                        }`}
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>

                  {envelope.status === 'completed' ? (
                    <button
                      onClick={() => setActiveCertModal(envelope)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-xs"
                    >
                      <FileCheck2 className="h-4 w-4 text-emerald-400" />
                      <span>View Certificate</span>
                    </button>
                  ) : (
                    <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                      <Clock className="h-3.5 w-3.5 mr-1" />
                      Ceremony In Flight
                    </span>
                  )}
                </div>

              </div>

              {/* Signers Sequential Routing Track */}
              <div className="pt-4">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
                  Recipient Routing Sequence &amp; Action
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {envelope.signers.map((signer) => {
                    const isSigned = signer.status === 'signed';
                    const isNextToSign = signer.status === 'delivered';
                    const isWaiting = signer.status === 'waiting';

                    return (
                      <div 
                        key={signer.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isSigned 
                            ? 'bg-emerald-50/50 border-emerald-200' 
                            : isNextToSign 
                            ? 'bg-amber-50/60 border-amber-300 ring-2 ring-amber-400/20' 
                            : 'bg-slate-50/70 border-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-bold text-slate-500 uppercase">
                            Step #{signer.routingOrder} &bull; {signer.role}
                          </span>
                          {isSigned ? (
                            <span className="inline-flex items-center text-xs font-semibold text-emerald-700">
                              <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Signed
                            </span>
                          ) : isNextToSign ? (
                            <span className="inline-flex items-center text-xs font-semibold text-amber-700 animate-pulse">
                              Ready to Sign
                            </span>
                          ) : (
                            <span className="text-xs text-slate-400 font-medium">Waiting turn</span>
                          )}
                        </div>

                        <div className="font-semibold text-slate-900 text-xs truncate">{signer.name}</div>
                        <div className="text-[11px] text-slate-500 truncate">{signer.email}</div>

                        {/* Interactive Sign or Reminder CTA */}
                        <div className="mt-3 pt-2.5 border-t border-slate-200/60 flex items-center justify-between">
                          {isSigned ? (
                            <span className="text-[10px] text-slate-500">
                              Signed: {new Date(signer.signedAt || '').toLocaleDateString()}
                            </span>
                          ) : isNextToSign ? (
                            <button
                              onClick={() => setActiveSignModal({ envelope, signer })}
                              className="w-full py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer transition-colors"
                            >
                              <PenTool className="h-3.5 w-3.5" />
                              <span>Execute E-Signature Now</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => handleReminder(envelope.envelopeId, signer.id)}
                              disabled={reminderSentFor === signer.id}
                              className="text-xs text-slate-600 hover:text-indigo-600 flex items-center gap-1 cursor-pointer transition-colors"
                            >
                              <Mail className="h-3 w-3" />
                              <span>{reminderSentFor === signer.id ? 'Reminder Sent!' : 'Send Reminder'}</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          );
        })}

        {filteredEnvelopes.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
            <FileSignature className="h-10 w-10 text-slate-400 mx-auto mb-2" />
            <h4 className="text-sm font-semibold text-slate-700">No Envelopes Found</h4>
            <p className="text-xs text-slate-500 mt-1">There are no DocuSign envelopes matching the selected status.</p>
          </div>
        )}
      </div>

      {/* Active Signature Modal */}
      {activeSignModal && (
        <DocuSignSignModal 
          envelope={activeSignModal.envelope}
          signer={activeSignModal.signer}
          onClose={() => setActiveSignModal(null)}
        />
      )}

      {/* Active Certificate Modal */}
      {activeCertModal && (
        <DocuSignCertificateModal 
          envelope={activeCertModal}
          onClose={() => setActiveCertModal(null)}
        />
      )}

    </div>
  );
};
