/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CLMProvider, useCLM } from './context/CLMContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { ContractList } from './components/contracts/ContractList';
import { ContractDetailModal } from './components/contracts/ContractDetailModal';
import { ContractFormModal } from './components/contracts/ContractFormModal';
import { RenewalHub } from './components/renewals/RenewalHub';
import { ObligationsManager } from './components/obligations/ObligationsManager';
import { DocuSignCenter } from './components/docusign/DocuSignCenter';
import { CollaborationHub } from './components/collaboration/CollaborationHub';
import { VendorDirectory } from './components/vendors/VendorDirectory';
import { AuditTrailView } from './components/audit/AuditTrailView';

function CLMApp() {
  const { 
    activeTab, 
    selectedContractId, 
    setSelectedContractId 
  } = useCLM();

  const [isNewContractModalOpen, setIsNewContractModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col antialiased text-slate-900 selection:bg-indigo-500 selection:text-white">
      
      {/* Top Navigation */}
      <Navbar 
        onOpenNewContractModal={() => setIsNewContractModalOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Main Layout Body */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Navigation Sidebar */}
        <Sidebar />

        {/* Dynamic Content Panel */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {activeTab === 'contracts' && (
            <ContractList 
              onOpenDetail={(id) => setSelectedContractId(id)}
              onOpenNewContract={() => setIsNewContractModalOpen(true)}
              searchQuery={searchQuery}
            />
          )}

          {activeTab === 'renewals' && (
            <RenewalHub />
          )}

          {activeTab === 'obligations' && (
            <ObligationsManager />
          )}

          {activeTab === 'docusign' && (
            <DocuSignCenter />
          )}

          {activeTab === 'collaboration' && (
            <CollaborationHub />
          )}

          {activeTab === 'vendors' && (
            <VendorDirectory />
          )}

          {activeTab === 'audit' && (
            <AuditTrailView />
          )}
        </main>

      </div>

      {/* Contract Detail Dossier Modal */}
      {selectedContractId && (
        <ContractDetailModal 
          contractId={selectedContractId}
          onClose={() => setSelectedContractId(null)}
        />
      )}

      {/* Create Contract Modal */}
      {isNewContractModalOpen && (
        <ContractFormModal 
          onClose={() => setIsNewContractModalOpen(false)}
        />
      )}

    </div>
  );
}

export default function App() {
  return (
    <CLMProvider>
      <CLMApp />
    </CLMProvider>
  );
}
