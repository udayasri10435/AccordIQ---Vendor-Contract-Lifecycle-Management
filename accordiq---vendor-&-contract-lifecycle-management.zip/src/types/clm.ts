export type ContractStatus = 
  | 'draft'
  | 'legal_review'
  | 'procurement_review'
  | 'pending_approval'
  | 'out_for_signature'
  | 'active'
  | 'renewal_due'
  | 'renewed'
  | 'expired'
  | 'terminated';

export type ContractType = 
  | 'MSA' 
  | 'SOW' 
  | 'SaaS Subscription' 
  | 'NDA' 
  | 'DPA' 
  | 'SLA' 
  | 'Vendor Agreement'
  | 'Software License';

export type ContractTier = 'Tier 1 (Mission Critical)' | 'Tier 2 (Operational)' | 'Tier 3 (Commodity)';

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

export interface Clause {
  id: string;
  title: string;
  category: 'Liability' | 'Indemnification' | 'Termination' | 'Governing Law' | 'Data Protection' | 'Payment Terms' | 'SLA & Penalties';
  standardText: string;
  currentText: string;
  isModified: boolean;
  riskLevel: RiskLevel;
  notes?: string;
}

export interface Obligation {
  id: string;
  contractId: string;
  contractTitle: string;
  vendorName: string;
  title: string;
  description: string;
  type: 'SLA' | 'Compliance & Audit' | 'Insurance (COI)' | 'Milestone Delivery' | 'Security Review' | 'Financial & Billing';
  dueDate: string;
  recurrence?: 'one-time' | 'monthly' | 'quarterly' | 'annual';
  assignedRole: 'Legal' | 'Procurement' | 'Vendor Lead' | 'InfoSec' | 'Finance';
  assigneeName: string;
  status: 'pending' | 'in_progress' | 'met' | 'at_risk' | 'overdue';
  penaltyTerms?: string;
  completedAt?: string;
  evidenceUrl?: string;
}

export interface DocuSignSigner {
  id: string;
  name: string;
  email: string;
  role: 'Vendor Executive' | 'Procurement Director' | 'General Counsel' | 'CFO';
  routingOrder: number;
  status: 'waiting' | 'sent' | 'delivered' | 'signed' | 'declined';
  signedAt?: string;
  ipAddress?: string;
  signatureImage?: string; // Data URL
  signatureType?: 'drawn' | 'typed';
}

export interface DocuSignEnvelope {
  id: string;
  envelopeId: string;
  contractId: string;
  contractTitle: string;
  status: 'draft' | 'sent' | 'delivered' | 'completed' | 'declined' | 'voided';
  createdDate: string;
  sentDate?: string;
  completedDate?: string;
  subject: string;
  signers: DocuSignSigner[];
  certificateHash?: string;
  totalDocuments: number;
}

export interface ApprovalStakeholder {
  role: 'Legal Counsel' | 'Head of Procurement' | 'Finance / CFO' | 'Business Owner';
  name: string;
  email: string;
  status: 'pending' | 'approved' | 'rejected' | 'changes_requested';
  comments?: string;
  decidedAt?: string;
}

export interface CollaborationNote {
  id: string;
  authorName: string;
  authorRole: 'Legal' | 'Procurement' | 'Executive' | 'Vendor Lead';
  authorAvatar?: string;
  timestamp: string;
  content: string;
  taggedClauses?: string[];
}

export interface AuditLogEntry {
  id: string;
  contractId?: string;
  contractTitle?: string;
  action: string;
  actorName: string;
  actorRole: string;
  timestamp: string;
  category: 'Creation' | 'Legal Review' | 'Procurement' | 'Approval' | 'E-Signature' | 'Renewal' | 'Obligation' | 'System';
  details: string;
  ipAddress: string;
  integrityHash: string;
}

export interface Vendor {
  id: string;
  name: string;
  category: string;
  website: string;
  tier: ContractTier;
  riskRating: RiskLevel;
  primaryContact: {
    name: string;
    email: string;
    phone: string;
    role: string;
  };
  contractsCount: number;
  totalAnnualSpend: number;
  currency: string;
  soc2Status: 'Compliant' | 'Pending Review' | 'Non-Compliant' | 'N/A';
  insuranceValidUntil: string;
  taxId: string;
  headquarters: string;
}

export interface Contract {
  id: string;
  contractNumber: string;
  title: string;
  vendorId: string;
  vendorName: string;
  type: ContractType;
  tier: ContractTier;
  status: ContractStatus;
  riskLevel: RiskLevel;
  totalValue: number;
  currency: string;
  billingFrequency: 'Annual' | 'Quarterly' | 'Monthly' | 'Milestone-based' | 'One-time';
  department: 'Engineering' | 'Legal' | 'Finance' | 'IT & Security' | 'Marketing' | 'Operations' | 'Human Resources';
  startDate: string;
  endDate: string;
  noticePeriodDays: number; // e.g. 60 days notice required
  autoRenew: boolean;
  renewalPriceCapPercent?: number; // e.g. 3% cap on renewal
  governingLaw: string; // e.g. "State of Delaware"
  liabilityCap: string; // e.g. "12 months fees paid"
  legalOwner: string;
  procurementOwner: string;
  businessOwner: string;
  clauses: Clause[];
  approvals: ApprovalStakeholder[];
  notes: CollaborationNote[];
  envelope?: DocuSignEnvelope;
  summary: string;
  documentFileName?: string;
  version: string;
  lastUpdated: string;
}

export type ActiveTab = 
  | 'contracts' 
  | 'renewals' 
  | 'obligations' 
  | 'docusign' 
  | 'collaboration' 
  | 'vendors' 
  | 'audit';
