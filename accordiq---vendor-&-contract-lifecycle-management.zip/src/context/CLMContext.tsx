import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Contract, 
  Vendor, 
  Obligation, 
  AuditLogEntry, 
  Clause, 
  ContractStatus, 
  ActiveTab,
  DocuSignEnvelope
} from '../types/clm';
import { 
  INITIAL_CONTRACTS, 
  INITIAL_VENDORS, 
  INITIAL_OBLIGATIONS, 
  INITIAL_AUDIT_LOGS,
  STANDARD_CLAUSE_TEMPLATES 
} from '../data/mockData';
import confetti from 'canvas-confetti';

export type CurrentUserRole = 'Legal' | 'Procurement' | 'Executive' | 'Vendor Lead';

export interface CurrentUser {
  name: string;
  role: CurrentUserRole;
  email: string;
  title: string;
}

export const AVAILABLE_USERS: CurrentUser[] = [
  {
    name: 'Marcus Sterling',
    role: 'Procurement',
    email: 'msterling@company.com',
    title: 'Head of Strategic Sourcing & Procurement'
  },
  {
    name: 'Rachel Zane',
    role: 'Legal',
    email: 'rzane@company.com',
    title: 'Senior Corporate Counsel'
  },
  {
    name: 'Sophia Chen',
    role: 'Executive',
    email: 'schen@company.com',
    title: 'Chief Financial Officer (CFO)'
  },
  {
    name: 'Tariq Al-Mansoor',
    role: 'Legal',
    email: 'talmansoor@company.com',
    title: 'Chief Information Security Officer (InfoSec)'
  },
  {
    name: 'Liam Zhang',
    role: 'Vendor Lead',
    email: 'lzhang@company.com',
    title: 'VP Engineering & Cloud Infrastructure'
  }
];

interface CLMContextType {
  contracts: Contract[];
  vendors: Vendor[];
  obligations: Obligation[];
  auditLogs: AuditLogEntry[];
  standardClauses: Clause[];
  currentUser: CurrentUser;
  setCurrentUser: (user: CurrentUser) => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  selectedContractId: string | null;
  setSelectedContractId: (id: string | null) => void;
  
  // Contract Actions
  addContract: (contract: Omit<Contract, 'id' | 'contractNumber' | 'lastUpdated'>) => string;
  updateContract: (id: string, updates: Partial<Contract>) => void;
  deleteContract: (id: string) => void;
  updateContractStatus: (id: string, newStatus: ContractStatus, reason?: string) => void;
  
  // Collaboration & Approvals
  addCollaborationNote: (contractId: string, content: string, taggedClauses?: string[]) => void;
  updateApprovalStatus: (contractId: string, role: string, status: 'approved' | 'rejected' | 'changes_requested', comments: string) => void;
  updateClause: (contractId: string, clauseId: string, newText: string, riskLevel?: Clause['riskLevel'], notes?: string) => void;
  restoreClauseToStandard: (contractId: string, clauseId: string) => void;

  // DocuSign Operations
  signDocuSignEnvelope: (
    envelopeId: string, 
    signerId: string, 
    signatureDataUrl: string, 
    signatureType: 'drawn' | 'typed'
  ) => void;
  sendDocuSignReminder: (envelopeId: string, signerId: string) => void;
  createDocuSignEnvelope: (contractId: string) => void;

  // Obligations
  addObligation: (obligation: Omit<Obligation, 'id'>) => void;
  updateObligationStatus: (
    id: string, 
    status: Obligation['status'], 
    notes?: string, 
    evidenceUrl?: string
  ) => void;

  // Renewal Actions
  initiateRenegotiation: (contractId: string, notes: string) => void;
  issueNonRenewalNotice: (contractId: string, reason: string) => void;
  executeAutoRenewal: (contractId: string, priceEscalationPercent?: number) => void;

  // Vendors
  addVendor: (vendor: Omit<Vendor, 'id' | 'contractsCount'>) => void;

  // Helpers & Audit
  addAuditLog: (log: Omit<AuditLogEntry, 'id' | 'timestamp' | 'integrityHash' | 'ipAddress'>) => void;
  resetAllData: () => void;
}

const CLMContext = createContext<CLMContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'accordiq_clm_store_v1';

export const CLMProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<CurrentUser>(AVAILABLE_USERS[0]);
  const [activeTab, setActiveTab] = useState<ActiveTab>('contracts');
  const [selectedContractId, setSelectedContractId] = useState<string | null>(null);

  // Initialize state with localStorage or defaults
  const [contracts, setContracts] = useState<Contract[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_contracts`);
    return saved ? JSON.parse(saved) : INITIAL_CONTRACTS;
  });

  const [vendors, setVendors] = useState<Vendor[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_vendors`);
    return saved ? JSON.parse(saved) : INITIAL_VENDORS;
  });

  const [obligations, setObligations] = useState<Obligation[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_obligations`);
    return saved ? JSON.parse(saved) : INITIAL_OBLIGATIONS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_audit`);
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  const [standardClauses] = useState<Clause[]>(STANDARD_CLAUSE_TEMPLATES);

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_contracts`, JSON.stringify(contracts));
  }, [contracts]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_vendors`, JSON.stringify(vendors));
  }, [vendors]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_obligations`, JSON.stringify(obligations));
  }, [obligations]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_audit`, JSON.stringify(auditLogs));
  }, [auditLogs]);

  const generateHash = () => {
    const chars = '0123456789abcdef';
    let hash = '';
    for (let i = 0; i < 64; i++) {
      hash += chars[Math.floor(Math.random() * chars.length)];
    }
    return hash;
  };

  const addAuditLog = (log: Omit<AuditLogEntry, 'id' | 'timestamp' | 'integrityHash' | 'ipAddress'>) => {
    const newEntry: AuditLogEntry = {
      ...log,
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      ipAddress: '192.0.2.' + (Math.floor(Math.random() * 200) + 10),
      integrityHash: generateHash()
    };
    setAuditLogs(prev => [newEntry, ...prev]);
  };

  const addContract = (data: Omit<Contract, 'id' | 'contractNumber' | 'lastUpdated'>): string => {
    const id = `cnt-${Date.now()}`;
    const contractNumber = `CTR-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newContract: Contract = {
      ...data,
      id,
      contractNumber,
      lastUpdated: new Date().toISOString()
    };

    setContracts(prev => [newContract, ...prev]);

    // Update vendor contract count
    setVendors(prev => prev.map(v => v.id === newContract.vendorId ? {
      ...v,
      contractsCount: v.contractsCount + 1,
      totalAnnualSpend: v.totalAnnualSpend + newContract.totalValue
    } : v));

    addAuditLog({
      contractId: id,
      contractTitle: newContract.title,
      action: 'Contract Created',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Creation',
      details: `New ${newContract.type} contract registered for ${newContract.vendorName} with total value $${newContract.totalValue.toLocaleString()}.`
    });

    return id;
  };

  const updateContract = (id: string, updates: Partial<Contract>) => {
    setContracts(prev => prev.map(c => {
      if (c.id === id) {
        return {
          ...c,
          ...updates,
          lastUpdated: new Date().toISOString()
        };
      }
      return c;
    }));

    addAuditLog({
      contractId: id,
      contractTitle: updates.title || 'Contract Update',
      action: 'Contract Details Modified',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Creation',
      details: `Modified fields: ${Object.keys(updates).join(', ')}`
    });
  };

  const deleteContract = (id: string) => {
    const target = contracts.find(c => c.id === id);
    if (!target) return;

    setContracts(prev => prev.filter(c => c.id !== id));
    setObligations(prev => prev.filter(o => o.contractId !== id));

    addAuditLog({
      contractId: id,
      contractTitle: target.title,
      action: 'Contract Archived / Removed',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Creation',
      details: `Contract ${target.contractNumber} archived by authorized user.`
    });
  };

  const updateContractStatus = (id: string, newStatus: ContractStatus, reason?: string) => {
    setContracts(prev => prev.map(c => {
      if (c.id === id) {
        return {
          ...c,
          status: newStatus,
          lastUpdated: new Date().toISOString()
        };
      }
      return c;
    }));

    const contract = contracts.find(c => c.id === id);
    addAuditLog({
      contractId: id,
      contractTitle: contract?.title,
      action: `Status Changed to ${newStatus.toUpperCase()}`,
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'System',
      details: reason ? `Reason: ${reason}` : `Lifecycle phase transition to ${newStatus}.`
    });
  };

  const addCollaborationNote = (contractId: string, content: string, taggedClauses?: string[]) => {
    const newNote = {
      id: `not-${Date.now()}`,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      timestamp: new Date().toISOString(),
      content,
      taggedClauses
    };

    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        return {
          ...c,
          notes: [newNote, ...c.notes],
          lastUpdated: new Date().toISOString()
        };
      }
      return c;
    }));

    const target = contracts.find(c => c.id === contractId);
    addAuditLog({
      contractId,
      contractTitle: target?.title,
      action: 'Collaboration Note Added',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: currentUser.role === 'Legal' ? 'Legal Review' : 'Procurement',
      details: `Comment: "${content.substring(0, 100)}${content.length > 100 ? '...' : ''}"`
    });
  };

  const updateApprovalStatus = (
    contractId: string, 
    role: string, 
    status: 'approved' | 'rejected' | 'changes_requested', 
    comments: string
  ) => {
    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        const updatedApprovals = c.approvals.map(app => {
          if (app.role === role) {
            return {
              ...app,
              status,
              comments,
              decidedAt: new Date().toISOString(),
              name: currentUser.name,
              email: currentUser.email
            };
          }
          return app;
        });

        // Check if all approved
        const allApproved = updatedApprovals.length > 0 && updatedApprovals.every(a => a.status === 'approved');
        const newContractStatus = allApproved ? 'out_for_signature' : (status === 'changes_requested' ? 'legal_review' : c.status);

        return {
          ...c,
          approvals: updatedApprovals,
          status: newContractStatus,
          lastUpdated: new Date().toISOString()
        };
      }
      return c;
    }));

    const target = contracts.find(c => c.id === contractId);
    addAuditLog({
      contractId,
      contractTitle: target?.title,
      action: `Approval Decision: ${role} -> ${status.toUpperCase()}`,
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Approval',
      details: comments ? `Stakeholder feedback: ${comments}` : `Decision registered by ${currentUser.name}.`
    });
  };

  const updateClause = (
    contractId: string, 
    clauseId: string, 
    newText: string, 
    riskLevel?: Clause['riskLevel'], 
    notes?: string
  ) => {
    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        const updatedClauses = c.clauses.map(cls => {
          if (cls.id === clauseId) {
            const isDiff = cls.standardText !== newText;
            return {
              ...cls,
              currentText: newText,
              isModified: isDiff,
              riskLevel: (riskLevel || (isDiff ? 'medium' : 'low')) as Clause['riskLevel'],
              notes: notes || cls.notes
            };
          }
          return cls;
        });
        return {
          ...c,
          clauses: updatedClauses,
          lastUpdated: new Date().toISOString()
        };
      }
      return c;
    }));

    const target = contracts.find(c => c.id === contractId);
    addAuditLog({
      contractId,
      contractTitle: target?.title,
      action: 'Contract Clause Redlined / Edited',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Legal Review',
      details: `Clause ${clauseId} modified. Risk assessed as ${riskLevel || 'medium'}.`
    });
  };

  const restoreClauseToStandard = (contractId: string, clauseId: string) => {
    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        const updatedClauses: Clause[] = c.clauses.map(cls => {
          if (cls.id === clauseId) {
            return {
              ...cls,
              currentText: cls.standardText,
              isModified: false,
              riskLevel: 'low' as const,
              notes: 'Restored to company pre-approved standard language.'
            };
          }
          return cls;
        });
        return {
          ...c,
          clauses: updatedClauses,
          lastUpdated: new Date().toISOString()
        };
      }
      return c;
    }));

    const target = contracts.find(c => c.id === contractId);
    addAuditLog({
      contractId,
      contractTitle: target?.title,
      action: 'Clause Restored to Pre-Approved Standard',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Legal Review',
      details: `Clause ${clauseId} restored to standard playbook language.`
    });
  };

  const createDocuSignEnvelope = (contractId: string) => {
    const contract = contracts.find(c => c.id === contractId);
    if (!contract) return;

    const envelopeId = `DOCU-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newEnvelope: DocuSignEnvelope = {
      id: `env-${Date.now()}`,
      envelopeId,
      contractId,
      contractTitle: contract.title,
      status: 'sent',
      createdDate: new Date().toISOString(),
      sentDate: new Date().toISOString(),
      subject: `Please DocuSign: ${contract.title}`,
      totalDocuments: 2,
      signers: [
        {
          id: `sgn-${Date.now()}-1`,
          name: 'Vendor Executive Representative',
          email: 'legal@vendor.com',
          role: 'Vendor Executive',
          routingOrder: 1,
          status: 'sent'
        },
        {
          id: `sgn-${Date.now()}-2`,
          name: currentUser.name,
          email: currentUser.email,
          role: 'Procurement Director',
          routingOrder: 2,
          status: 'waiting'
        },
        {
          id: `sgn-${Date.now()}-3`,
          name: 'Rachel Zane',
          email: 'rzane@company.com',
          role: 'General Counsel',
          routingOrder: 3,
          status: 'waiting'
        }
      ]
    };

    setContracts(prev => prev.map(c => c.id === contractId ? {
      ...c,
      status: 'out_for_signature',
      envelope: newEnvelope,
      lastUpdated: new Date().toISOString()
    } : c));

    addAuditLog({
      contractId,
      contractTitle: contract.title,
      action: 'DocuSign Envelope Generated & Dispatched',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'E-Signature',
      details: `Envelope ${envelopeId} dispatched to 3 signers with serial routing order.`
    });
  };

  const signDocuSignEnvelope = (
    envelopeId: string, 
    signerId: string, 
    signatureDataUrl: string, 
    signatureType: 'drawn' | 'typed'
  ) => {
    let completedEnvelope = false;
    let targetContractId = '';
    let targetContractTitle = '';

    setContracts(prev => prev.map(c => {
      if (c.envelope && c.envelope.envelopeId === envelopeId) {
        targetContractId = c.id;
        targetContractTitle = c.title;

        const updatedSigners = c.envelope.signers.map(s => {
          if (s.id === signerId) {
            return {
              ...s,
              status: 'signed' as const,
              signedAt: new Date().toISOString(),
              ipAddress: '192.0.2.' + (Math.floor(Math.random() * 200) + 10),
              signatureImage: signatureDataUrl,
              signatureType
            };
          }
          return s;
        });

        // Check if next signer needs to be promoted from 'waiting' to 'delivered'
        const signedCount = updatedSigners.filter(s => s.status === 'signed').length;
        const totalCount = updatedSigners.length;

        // Auto-deliver next in sequence
        for (let i = 0; i < updatedSigners.length; i++) {
          if (updatedSigners[i].status === 'waiting') {
            updatedSigners[i].status = 'delivered';
            break;
          }
        }

        const isAllSigned = signedCount === totalCount;
        if (isAllSigned) {
          completedEnvelope = true;
        }

        const newEnvelopeStatus = isAllSigned ? 'completed' : 'delivered';
        const newContractStatus = isAllSigned ? 'active' : c.status;

        return {
          ...c,
          status: newContractStatus,
          envelope: {
            ...c.envelope,
            status: newEnvelopeStatus,
            completedDate: isAllSigned ? new Date().toISOString() : undefined,
            certificateHash: isAllSigned ? generateHash() : c.envelope.certificateHash,
            signers: updatedSigners
          },
          lastUpdated: new Date().toISOString()
        };
      }
      return c;
    }));

    if (completedEnvelope) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // ignore if confetti fails
      }
    }

    addAuditLog({
      contractId: targetContractId,
      contractTitle: targetContractTitle,
      action: 'DocuSign E-Signature Executed',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'E-Signature',
      details: `Signer ${signerId} executed legally binding signature (${signatureType}). Status: ${completedEnvelope ? 'ENVELOPE COMPLETED - CONTRACT ACTIVATED' : 'In-Progress Signatures'}.`
    });
  };

  const sendDocuSignReminder = (envelopeId: string, signerId: string) => {
    const contract = contracts.find(c => c.envelope?.envelopeId === envelopeId);
    const signer = contract?.envelope?.signers.find(s => s.id === signerId);

    addAuditLog({
      contractId: contract?.id,
      contractTitle: contract?.title,
      action: 'DocuSign Reminder Sent',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'E-Signature',
      details: `Automated DocuSign email reminder dispatched to ${signer?.name} (${signer?.email}).`
    });
  };

  const addObligation = (obligation: Omit<Obligation, 'id'>) => {
    const newObligation: Obligation = {
      ...obligation,
      id: `ob-${Date.now()}`
    };

    setObligations(prev => [newObligation, ...prev]);

    addAuditLog({
      contractId: obligation.contractId,
      contractTitle: obligation.contractTitle,
      action: 'Obligation Scheduled',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Obligation',
      details: `New commitment logged: "${obligation.title}". Due date: ${obligation.dueDate}, Assigned to: ${obligation.assigneeName}.`
    });
  };

  const updateObligationStatus = (
    id: string, 
    status: Obligation['status'], 
    notes?: string, 
    evidenceUrl?: string
  ) => {
    setObligations(prev => prev.map(o => {
      if (o.id === id) {
        return {
          ...o,
          status,
          completedAt: status === 'met' ? new Date().toISOString() : undefined,
          evidenceUrl: evidenceUrl || o.evidenceUrl
        };
      }
      return o;
    }));

    const obligation = obligations.find(o => o.id === id);
    addAuditLog({
      contractId: obligation?.contractId,
      contractTitle: obligation?.contractTitle,
      action: `Obligation Status: ${status.toUpperCase()}`,
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Obligation',
      details: `Obligation "${obligation?.title}" updated to ${status}. ${notes ? `Notes: ${notes}` : ''}`
    });
  };

  const initiateRenegotiation = (contractId: string, notes: string) => {
    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        return {
          ...c,
          status: 'procurement_review',
          lastUpdated: new Date().toISOString(),
          notes: [
            {
              id: `not-${Date.now()}`,
              authorName: currentUser.name,
              authorRole: 'Procurement',
              timestamp: new Date().toISOString(),
              content: `RENEWAL RENEGOTIATION INITIATED: ${notes}`
            },
            ...c.notes
          ]
        };
      }
      return c;
    }));

    const target = contracts.find(c => c.id === contractId);
    addAuditLog({
      contractId,
      contractTitle: target?.title,
      action: 'Renewal Renegotiation Initiated',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Renewal',
      details: `Procurement opened renewal renegotiation track. Objective: ${notes}`
    });
  };

  const issueNonRenewalNotice = (contractId: string, reason: string) => {
    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        return {
          ...c,
          status: 'terminated',
          autoRenew: false,
          lastUpdated: new Date().toISOString(),
          notes: [
            {
              id: `not-${Date.now()}`,
              authorName: currentUser.name,
              authorRole: 'Procurement',
              timestamp: new Date().toISOString(),
              content: `FORMAL NON-RENEWAL NOTICE ISSUED: ${reason}`
            },
            ...c.notes
          ]
        };
      }
      return c;
    }));

    const target = contracts.find(c => c.id === contractId);
    addAuditLog({
      contractId,
      contractTitle: target?.title,
      action: 'Formal Non-Renewal Notice Dispatched',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Renewal',
      details: `Contract marked for expiration at end of current period. Auto-renew revoked. Reason: ${reason}`
    });
  };

  const executeAutoRenewal = (contractId: string, priceEscalationPercent: number = 3.0) => {
    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        // Calculate new end date (+1 year)
        const oldEnd = new Date(c.endDate);
        const newEnd = new Date(oldEnd);
        newEnd.setFullYear(oldEnd.getFullYear() + 1);

        const escalationMultiplier = 1 + (priceEscalationPercent / 100);
        const newValue = Math.round(c.totalValue * escalationMultiplier);

        return {
          ...c,
          status: 'active',
          startDate: c.endDate,
          endDate: newEnd.toISOString().split('T')[0],
          totalValue: newValue,
          version: (parseFloat(c.version) + 1.0).toFixed(1),
          lastUpdated: new Date().toISOString()
        };
      }
      return c;
    }));

    const target = contracts.find(c => c.id === contractId);
    addAuditLog({
      contractId,
      contractTitle: target?.title,
      action: 'Contract Term Renewed for 12 Months',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Renewal',
      details: `Term extended by 1 year. Value escalated by ${priceEscalationPercent}% to reflect renewal index.`
    });
  };

  const addVendor = (vendorData: Omit<Vendor, 'id' | 'contractsCount'>) => {
    const id = `ven-${Date.now()}`;
    const newVendor: Vendor = {
      ...vendorData,
      id,
      contractsCount: 0
    };
    setVendors(prev => [newVendor, ...prev]);

    addAuditLog({
      action: 'New Vendor Onboarded',
      actorName: currentUser.name,
      actorRole: currentUser.title,
      category: 'Procurement',
      details: `Vendor ${newVendor.name} registered under tier ${newVendor.tier}.`
    });
  };

  const resetAllData = () => {
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_contracts`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_vendors`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_obligations`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_audit`);
    setContracts(INITIAL_CONTRACTS);
    setVendors(INITIAL_VENDORS);
    setObligations(INITIAL_OBLIGATIONS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
  };

  return (
    <CLMContext.Provider value={{
      contracts,
      vendors,
      obligations,
      auditLogs,
      standardClauses,
      currentUser,
      setCurrentUser,
      activeTab,
      setActiveTab,
      selectedContractId,
      setSelectedContractId,
      addContract,
      updateContract,
      deleteContract,
      updateContractStatus,
      addCollaborationNote,
      updateApprovalStatus,
      updateClause,
      restoreClauseToStandard,
      createDocuSignEnvelope,
      signDocuSignEnvelope,
      sendDocuSignReminder,
      addObligation,
      updateObligationStatus,
      initiateRenegotiation,
      issueNonRenewalNotice,
      executeAutoRenewal,
      addVendor,
      addAuditLog,
      resetAllData
    }}>
      {children}
    </CLMContext.Provider>
  );
};

export const useCLM = () => {
  const context = useContext(CLMContext);
  if (!context) {
    throw new Error('useCLM must be used within a CLMProvider');
  }
  return context;
};
