import { Contract, Vendor, Obligation, AuditLogEntry, Clause } from '../types/clm';

export const INITIAL_VENDORS: Vendor[] = [
  {
    id: 'ven-1',
    name: 'Amazon Web Services (AWS)',
    category: 'Cloud Infrastructure & Compute',
    website: 'https://aws.amazon.com',
    tier: 'Tier 1 (Mission Critical)',
    riskRating: 'low',
    primaryContact: {
      name: 'Sarah Jenkins',
      email: 's-jenkins@amazon.com',
      phone: '+1 (206) 555-0192',
      role: 'Enterprise Strategic Account Executive'
    },
    contractsCount: 2,
    totalAnnualSpend: 420000,
    currency: 'USD',
    soc2Status: 'Compliant',
    insuranceValidUntil: '2027-03-31',
    taxId: 'US-91-1646860',
    headquarters: 'Seattle, WA, USA'
  },
  {
    id: 'ven-2',
    name: 'Snowflake Computing Inc.',
    category: 'Data Cloud & Analytics',
    website: 'https://snowflake.com',
    tier: 'Tier 1 (Mission Critical)',
    riskRating: 'low',
    primaryContact: {
      name: 'David Vance',
      email: 'dvance@snowflake.com',
      phone: '+1 (650) 555-0811',
      role: 'Director of Enterprise Accounts'
    },
    contractsCount: 1,
    totalAnnualSpend: 185000,
    currency: 'USD',
    soc2Status: 'Compliant',
    insuranceValidUntil: '2026-11-15',
    taxId: 'US-45-5462820',
    headquarters: 'Bozeman, MT, USA'
  },
  {
    id: 'ven-3',
    name: 'Salesforce.com Inc.',
    category: 'CRM & Sales Enablement',
    website: 'https://salesforce.com',
    tier: 'Tier 1 (Mission Critical)',
    riskRating: 'medium',
    primaryContact: {
      name: 'Elena Rostova',
      email: 'erostova@salesforce.com',
      phone: '+1 (415) 555-4309',
      role: 'VP Commercial Software Sales'
    },
    contractsCount: 2,
    totalAnnualSpend: 310000,
    currency: 'USD',
    soc2Status: 'Compliant',
    insuranceValidUntil: '2026-12-31',
    taxId: 'US-94-3320693',
    headquarters: 'San Francisco, CA, USA'
  },
  {
    id: 'ven-4',
    name: 'CrowdStrike Falcon',
    category: 'Cybersecurity & Endpoint Protection',
    website: 'https://crowdstrike.com',
    tier: 'Tier 1 (Mission Critical)',
    riskRating: 'low',
    primaryContact: {
      name: 'Marcus Brody',
      email: 'mbrody@crowdstrike.com',
      phone: '+1 (408) 555-7721',
      role: 'Cybersecurity Contracts Manager'
    },
    contractsCount: 1,
    totalAnnualSpend: 145000,
    currency: 'USD',
    soc2Status: 'Compliant',
    insuranceValidUntil: '2027-01-20',
    taxId: 'US-45-3805652',
    headquarters: 'Austin, TX, USA'
  },
  {
    id: 'ven-5',
    name: 'Datadog Inc.',
    category: 'DevOps & Observability',
    website: 'https://datadoghq.com',
    tier: 'Tier 2 (Operational)',
    riskRating: 'medium',
    primaryContact: {
      name: 'Chloe Mercer',
      email: 'cmercer@datadoghq.com',
      phone: '+1 (866) 329-4466',
      role: 'Strategic Customer Success'
    },
    contractsCount: 1,
    totalAnnualSpend: 92000,
    currency: 'USD',
    soc2Status: 'Compliant',
    insuranceValidUntil: '2026-10-30',
    taxId: 'US-27-2441993',
    headquarters: 'New York, NY, USA'
  },
  {
    id: 'ven-6',
    name: 'Cooley LLP',
    category: 'Outside Legal Counsel',
    website: 'https://cooley.com',
    tier: 'Tier 2 (Operational)',
    riskRating: 'low',
    primaryContact: {
      name: 'Jonathan Sterling',
      email: 'jsterling@cooley.com',
      phone: '+1 (212) 555-9000',
      role: 'Senior Partner, Corporate Governance'
    },
    contractsCount: 1,
    totalAnnualSpend: 250000,
    currency: 'USD',
    soc2Status: 'N/A',
    insuranceValidUntil: '2027-06-30',
    taxId: 'US-94-1185340',
    headquarters: 'Palo Alto, CA, USA'
  },
  {
    id: 'ven-7',
    name: 'Twilio Inc.',
    category: 'CPaaS & Telephony API',
    website: 'https://twilio.com',
    tier: 'Tier 3 (Commodity)',
    riskRating: 'low',
    primaryContact: {
      name: 'Rajiv Patel',
      email: 'rpatel@twilio.com',
      phone: '+1 (415) 555-8911',
      role: 'Commercial Account Manager'
    },
    contractsCount: 1,
    totalAnnualSpend: 48000,
    currency: 'USD',
    soc2Status: 'Compliant',
    insuranceValidUntil: '2026-12-01',
    taxId: 'US-26-2578091',
    headquarters: 'San Francisco, CA, USA'
  }
];

export const STANDARD_CLAUSE_TEMPLATES: Clause[] = [
  {
    id: 'cls-tpl-1',
    title: 'Limitation of Liability Cap',
    category: 'Liability',
    standardText: 'Except for gross negligence, willful misconduct, or breach of confidentiality/data protection obligations, neither party\'s aggregate cumulative liability arising out of or related to this Agreement shall exceed twelve (12) months of fees paid or payable by Customer immediately preceding the claim.',
    currentText: 'Except for gross negligence, willful misconduct, or breach of confidentiality/data protection obligations, neither party\'s aggregate cumulative liability arising out of or related to this Agreement shall exceed twelve (12) months of fees paid or payable by Customer immediately preceding the claim.',
    isModified: false,
    riskLevel: 'low',
    notes: 'Legal standard approved cap (12 months trailing fees).'
  },
  {
    id: 'cls-tpl-2',
    title: 'Intellectual Property Indemnification',
    category: 'Indemnification',
    standardText: 'Vendor shall defend, indemnify, and hold harmless Customer and its officers, directors, and employees against any third-party claims alleging that the software, services, or deliverables infringe any patent, copyright, trademark, or trade secret, with no dollar cap on indemnity obligation.',
    currentText: 'Vendor shall defend, indemnify, and hold harmless Customer and its officers, directors, and employees against any third-party claims alleging that the software, services, or deliverables infringe any patent, copyright, trademark, or trade secret, with no dollar cap on indemnity obligation.',
    isModified: false,
    riskLevel: 'low',
    notes: 'Uncapped IP indemnification required for all SaaS and software.'
  },
  {
    id: 'cls-tpl-3',
    title: 'Governing Law and Jurisdiction',
    category: 'Governing Law',
    standardText: 'This Agreement shall be governed by, and construed in accordance with, the laws of the State of Delaware, without regard to its conflict of law principles. Any legal suit or proceeding shall be instituted exclusively in the federal or state courts located in New Castle County, Delaware.',
    currentText: 'This Agreement shall be governed by, and construed in accordance with, the laws of the State of Delaware, without regard to its conflict of law principles. Any legal suit or proceeding shall be instituted exclusively in the federal or state courts located in New Castle County, Delaware.',
    isModified: false,
    riskLevel: 'low',
    notes: 'Delaware law preferred corporate governance forum.'
  },
  {
    id: 'cls-tpl-4',
    title: 'Termination for Convenience & Notice',
    category: 'Termination',
    standardText: 'Customer may terminate this Agreement or any applicable Order Form for convenience, with or without cause, upon thirty (30) days prior written notice to Vendor, with pro-rata refund of prepaid unearned fees.',
    currentText: 'Customer may terminate this Agreement or any applicable Order Form for convenience, with or without cause, upon thirty (30) days prior written notice to Vendor, with pro-rata refund of prepaid unearned fees.',
    isModified: false,
    riskLevel: 'low',
    notes: 'Procurement requirement for multi-year contracts.'
  },
  {
    id: 'cls-tpl-5',
    title: 'Information Security & Annual SOC2 Audit',
    category: 'Data Protection',
    standardText: 'Vendor shall maintain administrative, physical, and technical safeguards compliant with ISO 27001 or SOC 2 Type II standards, and shall provide Customer with an updated independent SOC 2 Type II examination report on an annual basis within thirty (30) days of issuance.',
    currentText: 'Vendor shall maintain administrative, physical, and technical safeguards compliant with ISO 27001 or SOC 2 Type II standards, and shall provide Customer with an updated independent SOC 2 Type II examination report on an annual basis within thirty (30) days of issuance.',
    isModified: false,
    riskLevel: 'low',
    notes: 'Mandatory InfoSec compliance safeguard.'
  }
];

export const INITIAL_CONTRACTS: Contract[] = [
  {
    id: 'cnt-101',
    contractNumber: 'CTR-2026-0042',
    title: 'Snowflake Enterprise Data Platform Master Subscription',
    vendorId: 'ven-2',
    vendorName: 'Snowflake Computing Inc.',
    type: 'SaaS Subscription',
    tier: 'Tier 1 (Mission Critical)',
    status: 'renewal_due', // Notice period is urgent!
    riskLevel: 'medium',
    totalValue: 185000,
    currency: 'USD',
    billingFrequency: 'Annual',
    department: 'Engineering',
    startDate: '2025-11-01',
    endDate: '2026-10-31',
    noticePeriodDays: 45, // Expiry is Oct 31, 2026. Current time is Sep 28, 2026. Only ~33 days left! Critical renewal window!
    autoRenew: true,
    renewalPriceCapPercent: 4.5,
    governingLaw: 'State of Delaware',
    liabilityCap: '12 months fees paid ($185,000 USD)',
    legalOwner: 'Rachel Zane (Senior Corporate Counsel)',
    procurementOwner: 'Marcus Sterling (Head of Strategic Sourcing)',
    businessOwner: 'Alex Rivera (VP Data Platform)',
    summary: 'Centralized enterprise cloud data warehouse contract covering 150TB storage allocation and analytical compute clusters for Core BI, Machine Learning pipelines, and Finance reporting.',
    documentFileName: 'Snowflake_Enterprise_MSA_2025_Executed.pdf',
    version: '2.1',
    lastUpdated: '2026-09-28T14:30:00Z',
    clauses: [
      {
        id: 'cls-101-1',
        title: 'Limitation of Liability Cap',
        category: 'Liability',
        standardText: 'Except for gross negligence or data breach, liability capped at 12 months fees paid.',
        currentText: 'In no event shall either party liability exceed 12 months fees paid under the applicable Order Form, except for uncapped indemnification.',
        isModified: false,
        riskLevel: 'low',
        notes: 'Standard mutual liability cap accepted.'
      },
      {
        id: 'cls-101-2',
        title: 'Auto-Renewal & Price Escalation',
        category: 'Termination',
        standardText: 'Notice of non-renewal must be provided at least 60 days before expiration. Annual renewal price increase capped at 3%.',
        currentText: 'This subscription automatically renews for successive 1-year terms unless either party provides 45 days written notice prior to term expiration. Renewal rate capped at 4.5% over prior period.',
        isModified: true,
        riskLevel: 'medium',
        notes: 'Vendor pushed for 6% escalation; procurement negotiated down to 4.5% cap.'
      },
      {
        id: 'cls-101-3',
        title: 'Service Level Agreement (SLA)',
        category: 'SLA & Penalties',
        standardText: 'Monthly availability of 99.95% with 10% credit for downtime below 99.9%.',
        currentText: 'Monthly platform uptime commitment of 99.9% with 10% credit for downtime between 99.0% and 99.9%, and 25% credit below 99.0%.',
        isModified: true,
        riskLevel: 'low',
        notes: 'Robust penalty schedule in place.'
      }
    ],
    approvals: [
      {
        role: 'Legal Counsel',
        name: 'Rachel Zane',
        email: 'rzane@company.com',
        status: 'approved',
        comments: 'Delaware law confirmed; data protection addendum attached.',
        decidedAt: '2025-10-22T10:15:00Z'
      },
      {
        role: 'Head of Procurement',
        name: 'Marcus Sterling',
        email: 'msterling@company.com',
        status: 'approved',
        comments: 'Secured $25k volume rebate on upfront annual commitment.',
        decidedAt: '2025-10-24T14:00:00Z'
      },
      {
        role: 'Finance / CFO',
        name: 'Sophia Chen',
        email: 'schen@company.com',
        status: 'approved',
        comments: 'Approved within FY25 cloud data budget.',
        decidedAt: '2025-10-25T09:30:00Z'
      },
      {
        role: 'Business Owner',
        name: 'Alex Rivera',
        email: 'arivera@company.com',
        status: 'approved',
        comments: 'Critical foundation for all unified analytics.',
        decidedAt: '2025-10-20T16:45:00Z'
      }
    ],
    notes: [
      {
        id: 'not-101-1',
        authorName: 'Marcus Sterling',
        authorRole: 'Procurement',
        timestamp: '2026-09-27T11:20:00Z',
        content: 'URGENT: Renewal date is October 31, 2026 with a 45-day notice window. We need to decide whether to exercise the 4.5% renewal cap or re-negotiate for multi-year multi-cloud discount.'
      },
      {
        id: 'not-101-2',
        authorName: 'Rachel Zane',
        authorRole: 'Legal',
        timestamp: '2026-09-28T09:15:00Z',
        content: 'Legal stands ready to issue the formal non-renewal or amendment notice before October 16 deadline.'
      }
    ],
    envelope: {
      id: 'env-101',
      envelopeId: 'DOCU-6B82-9901-44E2-F91A',
      contractId: 'cnt-101',
      contractTitle: 'Snowflake Enterprise Data Platform Master Subscription',
      status: 'completed',
      createdDate: '2025-10-25T11:00:00Z',
      sentDate: '2025-10-25T11:05:00Z',
      completedDate: '2025-10-26T15:42:10Z',
      subject: 'Please DocuSign: Snowflake Enterprise MSA 2025-2026',
      totalDocuments: 3,
      certificateHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      signers: [
        {
          id: 'sgn-1',
          name: 'David Vance',
          email: 'dvance@snowflake.com',
          role: 'Vendor Executive',
          routingOrder: 1,
          status: 'signed',
          signedAt: '2025-10-25T18:22:00Z',
          ipAddress: '198.51.100.44',
          signatureType: 'typed'
        },
        {
          id: 'sgn-2',
          name: 'Marcus Sterling',
          email: 'msterling@company.com',
          role: 'Procurement Director',
          routingOrder: 2,
          status: 'signed',
          signedAt: '2025-10-26T11:15:00Z',
          ipAddress: '203.0.113.89',
          signatureType: 'drawn'
        },
        {
          id: 'sgn-3',
          name: 'Rachel Zane',
          email: 'rzane@company.com',
          role: 'General Counsel',
          routingOrder: 3,
          status: 'signed',
          signedAt: '2025-10-26T15:42:10Z',
          ipAddress: '203.0.113.91',
          signatureType: 'typed'
        }
      ]
    }
  },
  {
    id: 'cnt-102',
    contractNumber: 'CTR-2026-0089',
    title: 'CrowdStrike Falcon Complete Security Services SOW',
    vendorId: 'ven-4',
    vendorName: 'CrowdStrike Falcon',
    type: 'SOW',
    tier: 'Tier 1 (Mission Critical)',
    status: 'out_for_signature', // Waiting on DocuSign signature ceremony!
    riskLevel: 'low',
    totalValue: 145000,
    currency: 'USD',
    billingFrequency: 'Annual',
    department: 'IT & Security',
    startDate: '2026-10-01',
    endDate: '2027-09-30',
    noticePeriodDays: 60,
    autoRenew: true,
    renewalPriceCapPercent: 3.0,
    governingLaw: 'State of Delaware',
    liabilityCap: '2x annual contract fees ($290,000 USD)',
    legalOwner: 'Rachel Zane (Senior Corporate Counsel)',
    procurementOwner: 'Marcus Sterling (Head of Strategic Sourcing)',
    businessOwner: 'Tariq Al-Mansoor (Chief Information Security Officer)',
    summary: '24/7 Managed Detection and Response (MDR) for 2,400 internal endpoints, threat hunting telemetry, and emergency breach incident warranty up to $1,000,000.',
    documentFileName: 'CrowdStrike_Falcon_Complete_SOW_2026_Final.pdf',
    version: '1.4',
    lastUpdated: '2026-09-28T16:10:00Z',
    clauses: [
      {
        id: 'cls-102-1',
        title: 'Cybersecurity Incident Response Warranty',
        category: 'Liability',
        standardText: 'Vendor provides incident breach remediation guarantee up to $1,000,000 per incident.',
        currentText: 'Vendor provides CrowdStrike Breach Response Warranty of up to $1,000,000 in qualifying incident response expenses.',
        isModified: false,
        riskLevel: 'low',
        notes: 'Pre-approved cybersecurity warranty clause.'
      },
      {
        id: 'cls-102-2',
        title: 'Data Retention & Telemetry Privacy',
        category: 'Data Protection',
        standardText: 'Customer endpoint telemetry must be retained solely in Customer designated cloud region (US-East) and purged upon contract termination.',
        currentText: 'Customer endpoint telemetry stored strictly within AWS US-East-1 with 90-day active retention and cryptographic destruction upon termination.',
        isModified: false,
        riskLevel: 'low',
        notes: 'Verified compliant with InfoSec data localization rules.'
      }
    ],
    approvals: [
      {
        role: 'Legal Counsel',
        name: 'Rachel Zane',
        email: 'rzane@company.com',
        status: 'approved',
        comments: 'Super liability cap and warranty clauses reviewed and verified.',
        decidedAt: '2026-09-26T15:20:00Z'
      },
      {
        role: 'Head of Procurement',
        name: 'Marcus Sterling',
        email: 'msterling@company.com',
        status: 'approved',
        comments: 'Secured 15% discount for 2,400 seats bundle.',
        decidedAt: '2026-09-27T10:30:00Z'
      },
      {
        role: 'Finance / CFO',
        name: 'Sophia Chen',
        email: 'schen@company.com',
        status: 'approved',
        comments: 'Approved under FY26 InfoSec capital allocation.',
        decidedAt: '2026-09-27T14:40:00Z'
      },
      {
        role: 'Business Owner',
        name: 'Tariq Al-Mansoor',
        email: 'talmansoor@company.com',
        status: 'approved',
        comments: 'Essential replacement for legacy antivirus before Q4.',
        decidedAt: '2026-09-25T11:00:00Z'
      }
    ],
    notes: [
      {
        id: 'not-102-1',
        authorName: 'Rachel Zane',
        authorRole: 'Legal',
        timestamp: '2026-09-27T16:00:00Z',
        content: 'All internal approvals completed. Envelope sent via DocuSign to Marcus Brody (Vendor) and Marcus Sterling (Procurement). Marcus Brody has signed; awaiting Marcus Sterling signature!'
      }
    ],
    envelope: {
      id: 'env-102',
      envelopeId: 'DOCU-7C91-4418-88B1-A03F',
      contractId: 'cnt-102',
      contractTitle: 'CrowdStrike Falcon Complete Security Services SOW',
      status: 'delivered',
      createdDate: '2026-09-27T16:30:00Z',
      sentDate: '2026-09-27T16:35:00Z',
      subject: 'Please Sign: CrowdStrike Falcon Complete SOW 2026-2027',
      totalDocuments: 2,
      signers: [
        {
          id: 'sgn-102-1',
          name: 'Marcus Brody',
          email: 'mbrody@crowdstrike.com',
          role: 'Vendor Executive',
          routingOrder: 1,
          status: 'signed',
          signedAt: '2026-09-28T09:12:00Z',
          ipAddress: '198.51.100.12',
          signatureType: 'typed'
        },
        {
          id: 'sgn-102-2',
          name: 'Marcus Sterling',
          email: 'msterling@company.com',
          role: 'Procurement Director',
          routingOrder: 2,
          status: 'delivered', // READY TO SIGN IN APP!
          signatureType: 'drawn'
        },
        {
          id: 'sgn-102-3',
          name: 'Rachel Zane',
          email: 'rzane@company.com',
          role: 'General Counsel',
          routingOrder: 3,
          status: 'waiting'
        }
      ]
    }
  },
  {
    id: 'cnt-103',
    contractNumber: 'CTR-2026-0104',
    title: 'AWS Enterprise Support & Reserved Compute Agreement',
    vendorId: 'ven-1',
    vendorName: 'Amazon Web Services (AWS)',
    type: 'MSA',
    tier: 'Tier 1 (Mission Critical)',
    status: 'active',
    riskLevel: 'low',
    totalValue: 420000,
    currency: 'USD',
    billingFrequency: 'Monthly',
    department: 'Engineering',
    startDate: '2026-01-01',
    endDate: '2027-12-31',
    noticePeriodDays: 90,
    autoRenew: false,
    renewalPriceCapPercent: 0,
    governingLaw: 'State of Washington',
    liabilityCap: '12 months fees paid ($420,000 USD)',
    legalOwner: 'Rachel Zane (Senior Corporate Counsel)',
    procurementOwner: 'Marcus Sterling (Head of Strategic Sourcing)',
    businessOwner: 'Liam Zhang (VP Engineering & Cloud Infra)',
    summary: '2-year committed spend agreement covering Enterprise Support concierge, dedicated Technical Account Manager (TAM), and 38% discounted Compute Savings Plan.',
    documentFileName: 'AWS_Enterprise_Addendum_2026_Executed.pdf',
    version: '3.0',
    lastUpdated: '2026-09-15T11:00:00Z',
    clauses: [
      {
        id: 'cls-103-1',
        title: 'Enterprise Support Response SLA',
        category: 'SLA & Penalties',
        standardText: 'Business critical system down response time within 15 minutes 24/7/365.',
        currentText: 'AWS provides 15-minute response time SLA for P1 Business-Critical system outages with direct phone escalation to Senior Cloud Support Engineers.',
        isModified: false,
        riskLevel: 'low',
        notes: 'Enterprise support tier verified.'
      },
      {
        id: 'cls-103-2',
        title: 'Data Sovereignty & Encryption',
        category: 'Data Protection',
        standardText: 'Customer data must remain encrypted at rest with Customer-Managed Keys (KMS) and never leave designated geographic bounds without authorization.',
        currentText: 'Customer retains exclusive control over encryption keys via AWS KMS; AWS Personnel have zero access to plaintext Customer payload data.',
        isModified: false,
        riskLevel: 'low',
        notes: 'Compliant with GDPR & SOC 2 specifications.'
      }
    ],
    approvals: [
      {
        role: 'Legal Counsel',
        name: 'Rachel Zane',
        email: 'rzane@company.com',
        status: 'approved',
        comments: 'Terms comply with company cloud security baseline.',
        decidedAt: '2025-12-18T10:00:00Z'
      },
      {
        role: 'Head of Procurement',
        name: 'Marcus Sterling',
        email: 'msterling@company.com',
        status: 'approved',
        comments: 'Yields estimated $160,000 annual compute discount.',
        decidedAt: '2025-12-19T14:30:00Z'
      },
      {
        role: 'Finance / CFO',
        name: 'Sophia Chen',
        email: 'schen@company.com',
        status: 'approved',
        comments: 'Savings plan approved in FY26-27 strategic runway.',
        decidedAt: '2025-12-20T11:15:00Z'
      },
      {
        role: 'Business Owner',
        name: 'Liam Zhang',
        email: 'lzhang@company.com',
        status: 'approved',
        comments: 'Backbone for all core production services.',
        decidedAt: '2025-12-15T09:00:00Z'
      }
    ],
    notes: [
      {
        id: 'not-103-1',
        authorName: 'Liam Zhang',
        authorRole: 'Vendor Lead',
        timestamp: '2026-09-10T14:00:00Z',
        content: 'Quarterly architecture review completed with AWS TAM. Compute utilization currently at 94.2% of reserved capacity.'
      }
    ],
    envelope: {
      id: 'env-103',
      envelopeId: 'DOCU-1A09-5561-33F8-B27E',
      contractId: 'cnt-103',
      contractTitle: 'AWS Enterprise Support & Reserved Compute Agreement',
      status: 'completed',
      createdDate: '2025-12-20T14:00:00Z',
      sentDate: '2025-12-20T14:05:00Z',
      completedDate: '2025-12-22T17:30:00Z',
      subject: 'DocuSign Executed: AWS Enterprise Commitment 2026-2027',
      totalDocuments: 4,
      certificateHash: 'f4b2389a0129bc564177d8a983421eef0984ba16538c201a45d0f6229bca0211',
      signers: [
        {
          id: 'sgn-103-1',
          name: 'Sarah Jenkins',
          email: 's-jenkins@amazon.com',
          role: 'Vendor Executive',
          routingOrder: 1,
          status: 'signed',
          signedAt: '2025-12-21T18:00:00Z',
          signatureType: 'typed'
        },
        {
          id: 'sgn-103-2',
          name: 'Marcus Sterling',
          email: 'msterling@company.com',
          role: 'Procurement Director',
          routingOrder: 2,
          status: 'signed',
          signedAt: '2025-12-22T11:00:00Z',
          signatureType: 'drawn'
        },
        {
          id: 'sgn-103-3',
          name: 'Rachel Zane',
          email: 'rzane@company.com',
          role: 'General Counsel',
          routingOrder: 3,
          status: 'signed',
          signedAt: '2025-12-22T17:30:00Z',
          signatureType: 'drawn'
        }
      ]
    }
  },
  {
    id: 'cnt-104',
    contractNumber: 'CTR-2026-0118',
    title: 'Salesforce Enterprise Revenue Cloud Addendum',
    vendorId: 'ven-3',
    vendorName: 'Salesforce.com Inc.',
    type: 'SaaS Subscription',
    tier: 'Tier 1 (Mission Critical)',
    status: 'legal_review', // Active collaboration room between Legal and Procurement
    riskLevel: 'high',
    totalValue: 310000,
    currency: 'USD',
    billingFrequency: 'Annual',
    department: 'Marketing',
    startDate: '2026-11-15',
    endDate: '2027-11-14',
    noticePeriodDays: 60,
    autoRenew: true,
    renewalPriceCapPercent: 7.0, // HIGH RISK CLAUSE!
    governingLaw: 'State of California',
    liabilityCap: 'Direct fees paid only (Excludes indirect)',
    legalOwner: 'Rachel Zane (Senior Corporate Counsel)',
    procurementOwner: 'Marcus Sterling (Head of Strategic Sourcing)',
    businessOwner: 'Cassandra Cole (Chief Revenue Officer)',
    summary: 'Renewal and seat expansion for 180 Sales Cloud licenses, CPQ automation, and Einstein Copilot telemetry.',
    documentFileName: 'Salesforce_RevenueCloud_OrderForm_Draft_v2.pdf',
    version: '1.2-redline',
    lastUpdated: '2026-09-28T17:45:00Z',
    clauses: [
      {
        id: 'cls-104-1',
        title: 'Auto-Renewal Price Escalator',
        category: 'Termination',
        standardText: 'Annual renewal price adjustment shall not exceed 3% or the annual CPI-U inflation rate, whichever is lower.',
        currentText: 'Salesforce reserves the right to increase annual subscription rates by up to 7% upon each automatic renewal term.',
        isModified: true,
        riskLevel: 'critical',
        notes: 'NON-STANDARD: Salesforce inserted a 7% annual compounding escalator. Procurement is counter-proposing 3.5%.'
      },
      {
        id: 'cls-104-2',
        title: 'Limitation of Liability & Data Security carve-out',
        category: 'Liability',
        standardText: 'Liability cap must contain a 3x super-cap or unlimited carve-out for unauthorized disclosure of customer personal information.',
        currentText: 'Neither party liability shall exceed direct damages up to total fees paid in the prior 12 months with no super-cap for security incidents.',
        isModified: true,
        riskLevel: 'high',
        notes: 'LEGAL REDLINE: Rachel Zane redlined this clause on Sep 28 to re-insert 2x super cap for data breach.'
      },
      {
        id: 'cls-104-3',
        title: 'Governing Law and Forum',
        category: 'Governing Law',
        standardText: 'State of Delaware courts.',
        currentText: 'State of California, County of San Francisco.',
        isModified: true,
        riskLevel: 'medium',
        notes: 'Vendor standard venue; acceptable if liability cap resolved.'
      }
    ],
    approvals: [
      {
        role: 'Legal Counsel',
        name: 'Rachel Zane',
        email: 'rzane@company.com',
        status: 'changes_requested',
        comments: 'Rejected Section 8.2 (7% price escalator) and Section 11 (lack of data breach liability super-cap). Redline v2 sent back to Elena Rostova.',
        decidedAt: '2026-09-28T16:30:00Z'
      },
      {
        role: 'Head of Procurement',
        name: 'Marcus Sterling',
        email: 'msterling@company.com',
        status: 'pending',
        comments: 'Holding off until legal issues are reconciled and vendor waives onboarding consulting fee.'
      },
      {
        role: 'Finance / CFO',
        name: 'Sophia Chen',
        email: 'schen@company.com',
        status: 'pending'
      },
      {
        role: 'Business Owner',
        name: 'Cassandra Cole',
        email: 'ccole@company.com',
        status: 'approved',
        comments: 'Sales ops needs this in place before Q4 pipeline kick-off.',
        decidedAt: '2026-09-25T14:10:00Z'
      }
    ],
    notes: [
      {
        id: 'not-104-1',
        authorName: 'Rachel Zane',
        authorRole: 'Legal',
        timestamp: '2026-09-28T17:00:00Z',
        content: 'Elena Rostova (Salesforce AE) agreed on phone that 7% was a default template error and said commercial desk can honor 3.5% if signed by month end. Awaiting revised draft.'
      },
      {
        id: 'not-104-2',
        authorName: 'Marcus Sterling',
        authorRole: 'Procurement',
        timestamp: '2026-09-28T17:15:00Z',
        content: 'Good catch Rachel. Make sure the 3.5% also applies to any additional user tiers we purchase mid-cycle.'
      }
    ]
  },
  {
    id: 'cnt-105',
    contractNumber: 'CTR-2026-0033',
    title: 'Datadog Infrastructure Monitoring & APM Pro',
    vendorId: 'ven-5',
    vendorName: 'Datadog Inc.',
    type: 'SaaS Subscription',
    tier: 'Tier 2 (Operational)',
    status: 'renewal_due', // ~32 days left
    riskLevel: 'medium',
    totalValue: 92000,
    currency: 'USD',
    billingFrequency: 'Annual',
    department: 'Engineering',
    startDate: '2025-10-31',
    endDate: '2026-10-30',
    noticePeriodDays: 30,
    autoRenew: true,
    renewalPriceCapPercent: 5.0,
    governingLaw: 'State of New York',
    liabilityCap: '12 months fees paid ($92,000 USD)',
    legalOwner: 'Rachel Zane (Senior Corporate Counsel)',
    procurementOwner: 'Marcus Sterling (Head of Strategic Sourcing)',
    businessOwner: 'Liam Zhang (VP Engineering & Cloud Infra)',
    summary: 'Full stack monitoring for 450 server hosts, Kubernetes telemetry, synthetic monitoring, and 15-day log archive ingestion.',
    documentFileName: 'Datadog_Master_Subscription_2025.pdf',
    version: '1.0',
    lastUpdated: '2026-09-26T10:00:00Z',
    clauses: [
      {
        id: 'cls-105-1',
        title: 'Data Retention & Ingestion Limits',
        category: 'Data Protection',
        standardText: 'Overage rates capped at standard tier pricing with 10-day notice prior to overage billing.',
        currentText: 'Overage charges billed at $0.10 per GB of ingested logs without prior notice buffer.',
        isModified: true,
        riskLevel: 'medium',
        notes: 'Procurement wants to lock in fixed pool.'
      }
    ],
    approvals: [
      {
        role: 'Legal Counsel',
        name: 'Rachel Zane',
        email: 'rzane@company.com',
        status: 'approved',
        decidedAt: '2025-10-15T11:00:00Z'
      },
      {
        role: 'Head of Procurement',
        name: 'Marcus Sterling',
        email: 'msterling@company.com',
        status: 'approved',
        decidedAt: '2025-10-16T14:00:00Z'
      },
      {
        role: 'Finance / CFO',
        name: 'Sophia Chen',
        email: 'schen@company.com',
        status: 'approved',
        decidedAt: '2025-10-17T09:00:00Z'
      },
      {
        role: 'Business Owner',
        name: 'Liam Zhang',
        email: 'lzhang@company.com',
        status: 'approved',
        decidedAt: '2025-10-14T16:00:00Z'
      }
    ],
    notes: [
      {
        id: 'not-105-1',
        authorName: 'Marcus Sterling',
        authorRole: 'Procurement',
        timestamp: '2026-09-26T10:30:00Z',
        content: 'Notice window closes on September 30 (30 days before Oct 30 expiration). We need to decide whether to let auto-renew or initiate renegotiation for higher log ingestion buffer.'
      }
    ]
  },
  {
    id: 'cnt-106',
    contractNumber: 'CTR-2026-0155',
    title: 'Cooley LLP Outside Corporate Legal Retainer',
    vendorId: 'ven-6',
    vendorName: 'Cooley LLP',
    type: 'Vendor Agreement',
    tier: 'Tier 2 (Operational)',
    status: 'active',
    riskLevel: 'low',
    totalValue: 250000,
    currency: 'USD',
    billingFrequency: 'Quarterly',
    department: 'Legal',
    startDate: '2026-07-01',
    endDate: '2027-06-30',
    noticePeriodDays: 30,
    autoRenew: false,
    renewalPriceCapPercent: 0,
    governingLaw: 'State of California',
    liabilityCap: 'Professional liability insurance policy limit ($25M)',
    legalOwner: 'Rachel Zane (Senior Corporate Counsel)',
    procurementOwner: 'Marcus Sterling (Head of Strategic Sourcing)',
    businessOwner: 'Rachel Zane (Senior Corporate Counsel)',
    summary: 'Outside corporate legal advisory covering Series C governance, patent filings, international expansion, and employment compliance.',
    documentFileName: 'Cooley_Retainer_Engagement_2026.pdf',
    version: '1.0',
    lastUpdated: '2026-07-02T10:00:00Z',
    clauses: [],
    approvals: [
      {
        role: 'Legal Counsel',
        name: 'Rachel Zane',
        email: 'rzane@company.com',
        status: 'approved',
        decidedAt: '2026-06-25T11:00:00Z'
      },
      {
        role: 'Finance / CFO',
        name: 'Sophia Chen',
        email: 'schen@company.com',
        status: 'approved',
        decidedAt: '2026-06-26T15:00:00Z'
      }
    ],
    notes: []
  },
  {
    id: 'cnt-107',
    contractNumber: 'CTR-2026-0190',
    title: 'Twilio SMS & Voice Delivery Communications DPA',
    vendorId: 'ven-7',
    vendorName: 'Twilio Inc.',
    type: 'DPA',
    tier: 'Tier 3 (Commodity)',
    status: 'active',
    riskLevel: 'low',
    totalValue: 48000,
    currency: 'USD',
    billingFrequency: 'Monthly',
    department: 'Engineering',
    startDate: '2026-03-01',
    endDate: '2027-02-28',
    noticePeriodDays: 30,
    autoRenew: true,
    renewalPriceCapPercent: 2.0,
    governingLaw: 'State of California',
    liabilityCap: '12 months fees paid',
    legalOwner: 'Rachel Zane (Senior Corporate Counsel)',
    procurementOwner: 'Marcus Sterling (Head of Strategic Sourcing)',
    businessOwner: 'Alex Rivera (VP Data Platform)',
    summary: 'Data Processing Addendum (DPA) covering customer SMS notifications, two-factor auth (2FA) codes, and GDPR/CCPA processor obligations.',
    documentFileName: 'Twilio_Executed_DPA_2026.pdf',
    version: '1.1',
    lastUpdated: '2026-03-05T09:00:00Z',
    clauses: [],
    approvals: [],
    notes: []
  }
];

export const INITIAL_OBLIGATIONS: Obligation[] = [
  {
    id: 'ob-1',
    contractId: 'cnt-101',
    contractTitle: 'Snowflake Enterprise Data Platform Master Subscription',
    vendorName: 'Snowflake Computing Inc.',
    title: 'Annual SOC 2 Type II Compliance Report Delivery',
    description: 'Vendor must furnish current SOC 2 Type II audit report covering security, availability, and confidentiality trust principles.',
    type: 'Compliance & Audit',
    dueDate: '2026-10-15',
    recurrence: 'annual',
    assignedRole: 'InfoSec',
    assigneeName: 'Tariq Al-Mansoor',
    status: 'at_risk', // Notice: October 15 is approaching!
    penaltyTerms: 'Failure to provide within 30 days entitles Customer to terminate for cause with full refund.'
  },
  {
    id: 'ob-2',
    contractId: 'cnt-101',
    contractTitle: 'Snowflake Enterprise Data Platform Master Subscription',
    vendorName: 'Snowflake Computing Inc.',
    title: 'Renewal / Non-Renewal Written Notice Window',
    description: 'Mandatory 45-day notice window to cancel auto-renewal or exercise renegotiated 4.5% rate cap.',
    type: 'Financial & Billing',
    dueDate: '2026-10-16', // 45 days before Oct 31 is Sep 16, or from Oct 31 notice
    recurrence: 'one-time',
    assignedRole: 'Procurement',
    assigneeName: 'Marcus Sterling',
    status: 'pending',
    penaltyTerms: 'Failure to give written notice results in automatic 12-month lock-in with 4.5% escalator.'
  },
  {
    id: 'ob-3',
    contractId: 'cnt-102',
    contractTitle: 'CrowdStrike Falcon Complete Security Services SOW',
    vendorName: 'CrowdStrike Falcon',
    title: 'Certificate of Insurance (COI) Verification',
    description: 'Annual submission of Cyber Liability insurance policy with minimum $10M aggregate coverage naming Customer as additional insured.',
    type: 'Insurance (COI)',
    dueDate: '2026-10-05',
    recurrence: 'annual',
    assignedRole: 'Legal',
    assigneeName: 'Rachel Zane',
    status: 'pending',
    penaltyTerms: 'Withholding of invoice disbursement until active COI on file.'
  },
  {
    id: 'ob-4',
    contractId: 'cnt-102',
    contractTitle: 'CrowdStrike Falcon Complete Security Services SOW',
    vendorName: 'CrowdStrike Falcon',
    title: 'Quarterly Breach Incident Tabletop Simulation',
    description: 'Vendor incident commanders must conduct joint mock incident response drill with internal security operations center.',
    type: 'Security Review',
    dueDate: '2026-11-20',
    recurrence: 'quarterly',
    assignedRole: 'InfoSec',
    assigneeName: 'Tariq Al-Mansoor',
    status: 'pending',
    penaltyTerms: '$5,000 SLA service credit per missed calendar quarter drill.'
  },
  {
    id: 'ob-5',
    contractId: 'cnt-103',
    contractTitle: 'AWS Enterprise Support & Reserved Compute Agreement',
    vendorName: 'Amazon Web Services (AWS)',
    title: 'Monthly Uptime Availability Verification (99.95% SLA)',
    description: 'Audit monthly compute availability across production multi-AZ availability zones in us-east-1 and us-west-2.',
    type: 'SLA',
    dueDate: '2026-10-01',
    recurrence: 'monthly',
    assignedRole: 'Vendor Lead',
    assigneeName: 'Liam Zhang',
    status: 'met',
    completedAt: '2026-09-25T14:00:00Z',
    evidenceUrl: 'https://status.aws.amazon.com/reports/2026-09-certified.pdf',
    penaltyTerms: '10% billing credit if uptime dips below 99.95%; 30% if below 99.0%.'
  },
  {
    id: 'ob-6',
    contractId: 'cnt-105',
    contractTitle: 'Datadog Infrastructure Monitoring & APM Pro',
    vendorName: 'Datadog Inc.',
    title: 'Auto-Renewal Notice Decision Deadline',
    description: '30-day notice required to prevent automatic 12-month extension at $96,600 (+5%).',
    type: 'Financial & Billing',
    dueDate: '2026-09-30', // DUE IN 2 DAYS!
    recurrence: 'one-time',
    assignedRole: 'Procurement',
    assigneeName: 'Marcus Sterling',
    status: 'at_risk',
    penaltyTerms: 'Automatic rollover for 1 year.'
  },
  {
    id: 'ob-7',
    contractId: 'cnt-104',
    contractTitle: 'Salesforce Enterprise Revenue Cloud Addendum',
    vendorName: 'Salesforce.com Inc.',
    title: 'DPA & Standard Contractual Clauses (SCC) Execution',
    description: 'Execute updated EU Standard Contractual Clauses for cross-border CRM telemetry transfers.',
    type: 'Compliance & Audit',
    dueDate: '2026-10-10',
    recurrence: 'one-time',
    assignedRole: 'Legal',
    assigneeName: 'Rachel Zane',
    status: 'in_progress',
    penaltyTerms: 'Regulatory non-compliance risk under GDPR Article 46.'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'aud-001',
    contractId: 'cnt-102',
    contractTitle: 'CrowdStrike Falcon Complete Security Services SOW',
    action: 'DocuSign Envelope Sent',
    actorName: 'Rachel Zane',
    actorRole: 'Senior Corporate Counsel',
    timestamp: '2026-09-27T16:35:00Z',
    category: 'E-Signature',
    details: 'Initiated 3-party DocuSign routing order. Envelope ID: DOCU-7C91-4418-88B1-A03F.',
    ipAddress: '192.0.2.14',
    integrityHash: '8f9a2b53c61e47d2b899a13b99e7102e34bf51a029c784e1bfa982a5146c21e9'
  },
  {
    id: 'aud-002',
    contractId: 'cnt-102',
    contractTitle: 'CrowdStrike Falcon Complete Security Services SOW',
    action: 'Vendor Signature Executed',
    actorName: 'Marcus Brody',
    actorRole: 'Cybersecurity Contracts Manager (Vendor)',
    timestamp: '2026-09-28T09:12:00Z',
    category: 'E-Signature',
    details: 'Signer 1 executed digital signature via DocuSign Certificate ID CS-7721.',
    ipAddress: '198.51.100.12',
    integrityHash: '3d5b8e99a10c42f887b12d59ca1873ea44b9101f3e721a9c4021bbfe81a3d905'
  },
  {
    id: 'aud-003',
    contractId: 'cnt-104',
    contractTitle: 'Salesforce Enterprise Revenue Cloud Addendum',
    action: 'Legal Redline Clause Modified',
    actorName: 'Rachel Zane',
    actorRole: 'Senior Corporate Counsel',
    timestamp: '2026-09-28T16:30:00Z',
    category: 'Legal Review',
    details: 'Rejected Section 8.2 (7% price escalator) and reinstated standard 3.5% ceiling; updated liability cap super-cap.',
    ipAddress: '192.0.2.14',
    integrityHash: 'b567a149c991e204b7721e8a93cb447192bf1804c8e73410a5b2e9871403ab62'
  },
  {
    id: 'aud-004',
    contractId: 'cnt-101',
    contractTitle: 'Snowflake Enterprise Data Platform Master Subscription',
    action: 'Renewal Notice Alert Triggered',
    actorName: 'AccordIQ Automated Sentinel',
    actorRole: 'System Cron',
    timestamp: '2026-09-28T08:00:00Z',
    category: 'Renewal',
    details: 'System flagged contract CTR-2026-0042 into 45-day critical notice window (Expiry: 2026-10-31). Sent alert to Marcus Sterling & Rachel Zane.',
    ipAddress: '10.0.4.88',
    integrityHash: '9a01bf2847c55e921d74b882310cefa7104928bfa17029cb781039de4120bf39'
  },
  {
    id: 'aud-005',
    contractId: 'cnt-103',
    contractTitle: 'AWS Enterprise Support & Reserved Compute Agreement',
    action: 'Obligation Marked Met',
    actorName: 'Liam Zhang',
    actorRole: 'VP Engineering & Cloud Infra',
    timestamp: '2026-09-25T14:00:00Z',
    category: 'Obligation',
    details: 'Verified Monthly Uptime SLA: 99.991% availability recorded for period 2026-08-25 to 2026-09-25. Evidence link attached.',
    ipAddress: '192.0.2.77',
    integrityHash: '1f44d82b9a7102e34bf51a029c784e1bfa982a5146c21e98f9a2b53c61e47d2b'
  }
];
